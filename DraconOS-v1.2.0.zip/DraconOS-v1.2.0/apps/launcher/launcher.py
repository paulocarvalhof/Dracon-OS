#!/usr/bin/env python3
# ============================================================
#   Dracon OS v1.2.0 — App Launcher
#   apps/launcher/launcher.py
# ============================================================

import curses, os, json, subprocess, time

DRACON_HOME  = os.path.expanduser("~/.dracon")
DRAPP_DB     = os.path.join(DRACON_HOME, "packages/drapp.json")
INSTALLED_DB = os.path.join(DRACON_HOME, "packages/installed.json")

# Built-in system apps
BUILTIN_APPS = [
    {"name": "Terminal",       "cmd": "xterm -bg '#0d1117' -fg '#c9d1d9' -fa Monospace -fs 11", "cat": "System",   "icon": "⬛"},
    {"name": "Dracon Store",   "cmd": "python3 ~/.dracon/apps/store/store.py",                   "cat": "System",   "icon": "🛍"},
    {"name": "Settings",       "cmd": "python3 ~/.dracon/apps/settings/settings.py",             "cat": "System",   "icon": "⚙"},
    {"name": "System Monitor", "cmd": "python3 ~/.dracon/bin/monitor.py",                        "cat": "System",   "icon": "📊"},
    {"name": "Calculator",     "cmd": "python3 ~/.dracon/apps/calculator/calc.py",               "cat": "Utilities","icon": "🔢"},
    {"name": "Text Editor",    "cmd": "python3 ~/.dracon/apps/editor/editor.py",                 "cat": "Utilities","icon": "✏"},
    {"name": "Volume",         "cmd": "bash ~/.dracon/bin/volume.sh",                            "cat": "System",   "icon": "🔊"},
    {"name": "Notifications",  "cmd": "python3 ~/.dracon/apps/notif/notif.py list",             "cat": "System",   "icon": "🔔"},
]

def load_drapp_apps():
    apps = []
    try:
        db = json.load(open(DRAPP_DB))
        for aid, info in db.get("apps", {}).items():
            apps.append({
                "name": info["name"],
                "cmd":  f"drapp run {aid}",
                "cat":  "Installed",
                "icon": "📦",
                "id":   aid,
            })
    except:
        pass
    return apps

def run_app(cmd, in_terminal=True):
    """Run app inside a new xterm window."""
    display = os.environ.get("DISPLAY", ":1")
    env = os.environ.copy()
    env["DISPLAY"] = display
    try:
        if in_terminal:
            full_cmd = (
                f"xterm -bg '#0d1117' -fg '#c9d1d9' -fa Monospace -fs 11 "
                f"-title 'Dracon OS' -e {cmd}"
            )
        else:
            full_cmd = cmd
        subprocess.Popen(full_cmd, shell=True, env=env,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception as e:
        pass

def draw_launcher(stdscr):
    curses.start_color()
    curses.init_pair(1, curses.COLOR_RED,    curses.COLOR_BLACK)
    curses.init_pair(2, curses.COLOR_WHITE,  curses.COLOR_BLACK)
    curses.init_pair(3, curses.COLOR_YELLOW, curses.COLOR_BLACK)
    curses.init_pair(4, curses.COLOR_CYAN,   curses.COLOR_BLACK)
    curses.init_pair(5, curses.COLOR_GREEN,  curses.COLOR_BLACK)
    curses.init_pair(6, curses.COLOR_BLACK,  curses.COLOR_RED)
    curses.curs_set(0)
    stdscr.keypad(True)

    ACC = curses.color_pair(1) | curses.A_BOLD
    NRM = curses.color_pair(2)
    YEL = curses.color_pair(3) | curses.A_BOLD
    CYN = curses.color_pair(4)
    GRN = curses.color_pair(5)
    HDR = curses.color_pair(6) | curses.A_BOLD
    DIM = curses.color_pair(2) | curses.A_DIM

    selected  = 0
    scroll    = 0
    search    = ""
    msg       = ""
    msg_timer = 0

    COLS = 3  # apps per row

    while True:
        all_apps  = BUILTIN_APPS + load_drapp_apps()
        filtered  = [a for a in all_apps
                     if search.lower() in a["name"].lower()
                     or search.lower() in a["cat"].lower()]

        h, w = stdscr.getmaxyx()
        stdscr.erase()

        # Header
        hdr = "  DRACON OS — APP LAUNCHER  "
        try:
            pad = " " * ((w - len(hdr)) // 2)
            stdscr.addstr(0, 0, (pad + hdr + pad)[:w], HDR)
        except: pass

        # Search bar
        try:
            stdscr.addstr(2, 2, "Search: ", DIM)
            stdscr.addstr(2, 10, f"{search}_"[:w-12], YEL if search else DIM)
            stdscr.addstr(2, w-20, f"{len(filtered)} apps", DIM)
        except: pass

        try: stdscr.addstr(3, 0, "─" * w, DIM)
        except: pass

        # App grid
        app_w    = max(20, (w - 4) // COLS)
        grid_h   = h - 8
        per_page = (grid_h // 4) * COLS

        if selected >= len(filtered):
            selected = max(0, len(filtered) - 1)

        page     = selected // per_page
        page_start = page * per_page

        row_offset = 4
        drawn = 0
        for idx in range(page_start, min(page_start + per_page, len(filtered))):
            app   = filtered[idx]
            col   = drawn % COLS
            row_n = drawn // COLS
            ax    = 2 + col * app_w
            ay    = row_offset + row_n * 4

            if ay + 3 >= h - 3:
                break

            is_sel = (idx == selected)
            bg     = YEL if is_sel else NRM
            border = ACC if is_sel else DIM

            try:
                # Box
                stdscr.addstr(ay,   ax, ("╔" + "═"*(app_w-4) + "╗")[:app_w-1], border)
                stdscr.addstr(ay+1, ax, "║", border)
                stdscr.addstr(ay+2, ax, "║", border)
                stdscr.addstr(ay+3, ax, ("╚" + "═"*(app_w-4) + "╝")[:app_w-1], border)
                # Content
                icon_name = f"{app['icon']} {app['name']}"
                stdscr.addstr(ay+1, ax+2, icon_name[:app_w-4], bg)
                stdscr.addstr(ay+2, ax+2, app["cat"][:app_w-4], CYN if not is_sel else YEL)
                stdscr.addstr(ay+1, ax+app_w-4, "║", border)
                stdscr.addstr(ay+2, ax+app_w-4, "║", border)
            except: pass

            drawn += 1

        # Message
        if msg and time.time() < msg_timer:
            try: stdscr.addstr(h-3, (w-len(msg))//2, msg, GRN)
            except: pass

        # Footer
        try: stdscr.addstr(h-2, 0, "─" * w, DIM)
        except: pass
        try: stdscr.addstr(h-1, 2,
            " Arrows:Move  Enter:Launch  /:Search  Q:Quit  I:Install .drapp "[:w-4], DIM)
        except: pass

        stdscr.refresh()

        # Input
        key = stdscr.getch()

        if key in (ord('q'), ord('Q'), 27) and not search:
            break
        elif key == 27:
            search = ""
        elif key == curses.KEY_RIGHT:
            selected = min(len(filtered)-1, selected+1)
        elif key == curses.KEY_LEFT:
            selected = max(0, selected-1)
        elif key == curses.KEY_DOWN:
            selected = min(len(filtered)-1, selected+COLS)
        elif key == curses.KEY_UP:
            selected = max(0, selected-COLS)
        elif key in (curses.KEY_ENTER, 10, 13):
            if filtered:
                app = filtered[selected]
                run_app(app["cmd"])
                msg = f" Launching {app['name']}... "
                msg_timer = time.time() + 2
        elif key == ord('/'):
            search = ""
        elif key in (curses.KEY_BACKSPACE, 127):
            search = search[:-1]
        elif key == ord('i') or key == ord('I'):
            msg = " drapp install <file.drapp> in terminal "
            msg_timer = time.time() + 3
        elif 32 <= key <= 126:
            search += chr(key)
            selected = 0


def main():
    try:
        curses.wrapper(draw_launcher)
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
