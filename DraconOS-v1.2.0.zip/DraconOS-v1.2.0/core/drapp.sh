#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
#   Dracon OS v1.2.0 — .drapp Package Manager
#   core/drapp.sh
# ============================================================

DRACON_HOME="$HOME/.dracon"
DRAPP_DIR="$DRACON_HOME/apps/installed"
DRAPP_DB="$DRACON_HOME/packages/drapp.json"

R='\033[0;31m'; G='\033[0;32m'; C='\033[0;36m'
Y='\033[1;33m'; W='\033[1;37m'; DIM='\033[2m'; NC='\033[0m'

mkdir -p "$DRAPP_DIR"
[ -f "$DRAPP_DB" ] || echo '{"apps":{}}' > "$DRAPP_DB"

log_ok()   { echo -e "  ${G}[ OK ]${NC}  $1"; }
log_err()  { echo -e "  ${R}[FAIL]${NC}  $1"; }
log_info() { echo -e "  ${C}[INFO]${NC}  $1"; }

banner() {
  echo -e "  ${R}drapp${NC} — ${W}Dracon App Manager${NC} ${DIM}v1.2.0${NC}"
  echo -e "  ${DIM}─────────────────────────────────${NC}"
}

# ─── Install .drapp ──────────────────────────────────────────
cmd_install() {
  local file="$1"

  if [ -z "$file" ]; then
    log_err "Usage: drapp install <file.drapp>"
    exit 1
  fi

  if [ ! -f "$file" ]; then
    log_err "File not found: $file"
    exit 1
  fi

  # Validate it's a zip
  if ! unzip -t "$file" &>/dev/null; then
    log_err "Invalid .drapp file (not a valid zip)"
    exit 1
  fi

  # Extract manifest
  local manifest
  manifest=$(unzip -p "$file" "*/manifest.json" 2>/dev/null || unzip -p "$file" "manifest.json" 2>/dev/null)
  if [ -z "$manifest" ]; then
    log_err "Missing manifest.json in .drapp"
    exit 1
  fi

  # Parse manifest fields
  local app_id app_name app_version app_author app_entry app_type
  app_id=$(echo "$manifest"      | python3 -c "import json,sys; print(json.load(sys.stdin).get('id',''))")
  app_name=$(echo "$manifest"    | python3 -c "import json,sys; print(json.load(sys.stdin).get('name',''))")
  app_version=$(echo "$manifest" | python3 -c "import json,sys; print(json.load(sys.stdin).get('version','1.0.0'))")
  app_author=$(echo "$manifest"  | python3 -c "import json,sys; print(json.load(sys.stdin).get('author',''))")
  app_entry=$(echo "$manifest"   | python3 -c "import json,sys; print(json.load(sys.stdin).get('entry','main.py'))")
  app_type=$(echo "$manifest"    | python3 -c "import json,sys; print(json.load(sys.stdin).get('type','python'))")

  if [ -z "$app_id" ] || [ -z "$app_name" ]; then
    log_err "Invalid manifest: missing 'id' or 'name'"
    exit 1
  fi

  log_info "Installing: $app_name v$app_version by $app_author"

  # Extract to apps dir
  local dest="$DRAPP_DIR/$app_id"
  rm -rf "$dest"
  mkdir -p "$dest"
  unzip -q "$file" -d "$dest" 2>/dev/null

  # Flatten if nested
  local inner
  inner=$(find "$dest" -name "manifest.json" | head -1 | xargs dirname)
  if [ "$inner" != "$dest" ] && [ -n "$inner" ]; then
    cp -r "$inner"/. "$dest/"
    rm -rf "$dest/$(basename "$inner")"
  fi

  # Create launcher script
  local launcher="$PREFIX/bin/drapp-$app_id"
  if [ "$app_type" = "python" ]; then
    cat > "$launcher" << EOF
#!/data/data/com.termux/files/usr/bin/bash
export DRACON_HOME="\$HOME/.dracon"
export DRAPP_DIR="$dest"
cd "$dest"
exec python3 "$dest/$app_entry" "\$@"
EOF
  else
    cat > "$launcher" << EOF
#!/data/data/com.termux/files/usr/bin/bash
export DRACON_HOME="\$HOME/.dracon"
export DRAPP_DIR="$dest"
cd "$dest"
exec bash "$dest/$app_entry" "\$@"
EOF
  fi
  chmod +x "$launcher"

  # Save to DB
  python3 - <<PYEOF
import json, datetime, os
db = json.load(open('$DRAPP_DB'))
db['apps']['$app_id'] = {
    "name": "$app_name",
    "version": "$app_version",
    "author": "$app_author",
    "type": "$app_type",
    "entry": "$app_entry",
    "path": "$dest",
    "launcher": "$launcher",
    "installed_at": datetime.datetime.now().isoformat()
}
json.dump(db, open('$DRAPP_DB','w'), indent=2)
PYEOF

  log_ok "$app_name v$app_version installed!"
  log_info "Run with: drapp run $app_id"
  log_info "Or from launcher: drapp-$app_id"
}

# ─── Run a .drapp ────────────────────────────────────────────
cmd_run() {
  local target="$1"
  if [ -z "$target" ]; then
    log_err "Usage: drapp run <id|file.drapp>"
    exit 1
  fi

  # Direct file
  if [ -f "$target" ] && [[ "$target" == *.drapp ]]; then
    local tmp="/tmp/drapp_run_$$"
    mkdir -p "$tmp"
    unzip -q "$target" -d "$tmp"
    local manifest inner
    inner=$(find "$tmp" -name "manifest.json" | head -1 | xargs dirname)
    manifest=$(cat "$inner/manifest.json")
    local entry type
    entry=$(echo "$manifest" | python3 -c "import json,sys; print(json.load(sys.stdin).get('entry','main.py'))")
    type=$(echo "$manifest"  | python3 -c "import json,sys; print(json.load(sys.stdin).get('type','python'))")
    export DRAPP_DIR="$inner"
    cd "$inner"
    if [ "$type" = "python" ]; then
      python3 "$inner/$entry"
    else
      bash "$inner/$entry"
    fi
    rm -rf "$tmp"
    return
  fi

  # Installed app by ID
  local launcher="$PREFIX/bin/drapp-$target"
  if [ -f "$launcher" ]; then
    exec "$launcher"
  else
    log_err "App '$target' not found. Use: drapp list"
    exit 1
  fi
}

# ─── List installed .drapp apps ──────────────────────────────
cmd_list() {
  banner
  echo -e "  ${W}Installed .drapp Applications${NC}\n"
  python3 - <<'PYEOF'
import json, os
db_path = os.path.expanduser("~/.dracon/packages/drapp.json")
try:
    db = json.load(open(db_path))
    apps = db.get("apps", {})
    if not apps:
        print("  \033[2mNo .drapp apps installed yet.\033[0m")
        print("  \033[2mInstall with: drapp install <file.drapp>\033[0m")
    else:
        print(f"  {'ID':<35} {'Name':<20} {'Ver':<10} {'Author'}")
        print("  " + "─"*80)
        for aid, info in sorted(apps.items()):
            print(f"  \033[0;32m{aid:<35}\033[0m {info['name']:<20} "
                  f"{info['version']:<10} \033[2m{info['author']}\033[0m")
except Exception as e:
    print(f"  Error: {e}")
PYEOF
  echo ""
}

# ─── Remove ──────────────────────────────────────────────────
cmd_remove() {
  local app_id="$1"
  if [ -z "$app_id" ]; then
    log_err "Usage: drapp remove <id>"
    exit 1
  fi

  python3 - <<PYEOF
import json, os, shutil
db_path = os.path.expanduser('~/.dracon/packages/drapp.json')
try:
    db = json.load(open(db_path))
    if '$app_id' not in db['apps']:
        print(f"  \033[0;31m[FAIL]\033[0m App not found: $app_id")
        exit(1)
    app = db['apps'].pop('$app_id')
    # Remove files
    if os.path.exists(app['path']):
        shutil.rmtree(app['path'])
    if os.path.exists(app['launcher']):
        os.remove(app['launcher'])
    json.dump(db, open(db_path,'w'), indent=2)
    print(f"  \033[0;32m[ OK ]\033[0m  {app['name']} removed.")
except Exception as e:
    print(f"  \033[0;31m[FAIL]\033[0m {e}")
PYEOF
}

# ─── Info ────────────────────────────────────────────────────
cmd_info() {
  local app_id="$1"
  python3 - <<PYEOF
import json, os
db = json.load(open(os.path.expanduser('~/.dracon/packages/drapp.json')))
app = db.get('apps',{}).get('$app_id')
if not app:
    print("  App not found: $app_id")
else:
    for k,v in app.items():
        print(f"  \033[0;36m{k:<15}\033[0m {v}")
PYEOF
}

# ─── Help ────────────────────────────────────────────────────
cmd_help() {
  banner
  echo -e "  ${W}Usage:${NC} drapp <command> [args]"
  echo ""
  echo -e "  ${C}Commands:${NC}"
  echo -e "    ${G}install${NC} <file.drapp>  Install a .drapp application"
  echo -e "    ${G}run${NC}     <id|file>     Run an installed app or .drapp file"
  echo -e "    ${G}remove${NC}  <id>          Uninstall an app"
  echo -e "    ${G}list${NC}                  List installed apps"
  echo -e "    ${G}info${NC}    <id>          Show app details"
  echo -e "    ${G}help${NC}                  Show this help"
  echo ""
  echo -e "  ${DIM}Example:${NC}"
  echo -e "    ${DIM}drapp install MeuApp.drapp${NC}"
  echo -e "    ${DIM}drapp run com.dev.meuapp${NC}"
  echo -e "    ${DIM}drapp list${NC}"
  echo ""
}

case "${1:-help}" in
  install) cmd_install "$2" ;;
  run)     cmd_run     "$2" ;;
  remove)  cmd_remove  "$2" ;;
  list)    cmd_list         ;;
  info)    cmd_info    "$2" ;;
  help|--help|-h) cmd_help ;;
  *)
    echo -e "  ${R}Unknown: $1${NC}"
    cmd_help; exit 1 ;;
esac
