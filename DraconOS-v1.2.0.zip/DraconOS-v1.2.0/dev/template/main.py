#!/usr/bin/env python3
# ============================================================
#   My Dracon App — Template
#   Dracon OS .drapp format
# ============================================================

import curses
import os

# Dracon OS environment variables
DRACON_HOME = os.environ.get("DRACON_HOME", os.path.expanduser("~/.dracon"))
APP_DIR     = os.environ.get("DRAPP_DIR", os.path.dirname(__file__))
APP_NAME    = "My Dracon App"
APP_VER     = "1.0.0"


def main(stdscr):
    # ── Setup colors ──────────────────────────────────────────
    curses.start_color()
    curses.init_pair(1, curses.COLOR_RED,   curses.COLOR_BLACK)  # accent
    curses.init_pair(2, curses.COLOR_WHITE, curses.COLOR_BLACK)  # normal
    curses.init_pair(3, curses.COLOR_CYAN,  curses.COLOR_BLACK)  # info
    curses.init_pair(4, curses.COLOR_BLACK, curses.COLOR_RED)    # header
    curses.curs_set(0)

    ACC = curses.color_pair(1) | curses.A_BOLD
    NRM = curses.color_pair(2)
    CYN = curses.color_pair(3)
    HDR = curses.color_pair(4) | curses.A_BOLD
    DIM = curses.color_pair(2) | curses.A_DIM

    while True:
        h, w = stdscr.getmaxyx()
        stdscr.erase()

        # ── Header ───────────────────────────────────────────
        title = f"  {APP_NAME} v{APP_VER}  "
        try:
            pad = " " * ((w - len(title)) // 2)
            stdscr.addstr(0, 0, (pad + title + pad)[:w], HDR)
        except:
            pass

        # ── Content ──────────────────────────────────────────
        try:
            stdscr.addstr(3, 4, "Hello from Dracon OS!", ACC)
            stdscr.addstr(5, 4, f"Dracon Home: {DRACON_HOME}", CYN)
            stdscr.addstr(6, 4, f"App Dir:     {APP_DIR}", DIM)
            stdscr.addstr(8, 4, "This is your app template.", NRM)
            stdscr.addstr(9, 4, "Edit main.py to build your app!", NRM)
        except:
            pass

        # ── Footer ───────────────────────────────────────────
        try:
            stdscr.addstr(h - 1, 2, " Q: Quit ", DIM)
        except:
            pass

        stdscr.refresh()

        # ── Input ─────────────────────────────────────────────
        key = stdscr.getch()
        if key in (ord('q'), ord('Q'), 27):
            break


if __name__ == "__main__":
    try:
        curses.wrapper(main)
    except KeyboardInterrupt:
        pass
