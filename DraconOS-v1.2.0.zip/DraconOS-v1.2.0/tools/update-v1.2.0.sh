#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
#   Dracon OS — Update to v1.2.0
#   tools/update-v1.2.0.sh
# ============================================================

DRACON_HOME="$HOME/.dracon"
SRC="$(cd "$(dirname "$0")/.." && pwd)"

R='\033[0;31m'; G='\033[0;32m'; C='\033[0;36m'
Y='\033[1;33m'; W='\033[1;37m'; DIM='\033[2m'; NC='\033[0m'

clear
echo -e "${R}"
echo '  ██████╗ ██████╗  █████╗  ██████╗ ██████╗ ███╗   ██╗'
echo '  ██╔══██╗██╔══██╗██╔══██╗██╔════╝██╔═══██╗████╗  ██║'
echo '  ██║  ██║██████╔╝███████║██║     ██║   ██║██╔██╗ ██║'
echo '  ██║  ██║██╔══██╗██╔══██║██║     ██║   ██║██║╚██╗██║'
echo '  ██████╔╝██║  ██║██║  ██║╚██████╗╚██████╔╝██║ ╚████║'
echo '  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝ ╚═════╝ ╚═╝  ╚═══╝'
echo -e "${W}               Updater → ${R}v1.2.0${NC}\n"

log_ok()   { echo -e "  ${G}[ OK ]${NC} $1"; }
log_info() { echo -e "  ${C}[INFO]${NC} $1"; }
log_step() { echo -e "\n  ${W}══ $1 ══${NC}"; }

log_step "Backing up v1.1.0"
cp -r "$DRACON_HOME" "$DRACON_HOME.bak.$(date +%Y%m%d_%H%M%S)" 2>/dev/null
log_ok "Backup saved"

log_step "Installing .drapp runtime"
mkdir -p "$DRACON_HOME/apps/installed"
[ -f "$DRACON_HOME/packages/drapp.json" ] || echo '{"apps":{}}' > "$DRACON_HOME/packages/drapp.json"

cp "$SRC/core/drapp.sh" "$DRACON_HOME/bin/"
chmod +x "$DRACON_HOME/bin/drapp.sh"

# Register drapp command
ln -sf "$DRACON_HOME/bin/drapp.sh" "$PREFIX/bin/drapp" 2>/dev/null
chmod +x "$PREFIX/bin/drapp" 2>/dev/null
log_ok ".drapp runtime installed"
log_ok "Command 'drapp' registered"

log_step "Installing App Launcher"
mkdir -p "$DRACON_HOME/apps/launcher"
cp "$SRC/apps/launcher/launcher.py" "$DRACON_HOME/apps/launcher/"
ln -sf "$DRACON_HOME/apps/launcher/launcher.py" "$PREFIX/bin/dracon-launcher" 2>/dev/null
chmod +x "$PREFIX/bin/dracon-launcher" 2>/dev/null
log_ok "App Launcher installed"

log_step "Installing image assets"
mkdir -p "$DRACON_HOME/assets/images/"{boot,wallpapers,icons,ui}
cp -r "$SRC/assets/" "$DRACON_HOME/" 2>/dev/null
log_ok "Assets folder created"

log_step "Installing developer tools"
mkdir -p "$DRACON_HOME/dev"
cp -r "$SRC/dev/"* "$DRACON_HOME/dev/" 2>/dev/null
log_ok "DRAPP_SPEC.md — developer documentation"
log_ok "Template project — ready to customize"

log_step "Applying bug fixes"

# Fix store - guard all addstr
cp "$SRC/apps/store/store.py" "$DRACON_HOME/apps/store/" 2>/dev/null
log_ok "Store crash fix applied"

# Fix settings
cp "$SRC/apps/settings/settings.py" "$DRACON_HOME/apps/settings/" 2>/dev/null
log_ok "Settings fix applied"

# Fix calculator
cp "$SRC/apps/calculator/calc.py" "$DRACON_HOME/apps/calculator/" 2>/dev/null
log_ok "Calculator fix applied"

# Fix editor
cp "$SRC/apps/editor/editor.py" "$DRACON_HOME/apps/editor/" 2>/dev/null
log_ok "Editor fix applied"

log_step "Updating desktop menu"
mkdir -p "$HOME/.config/openbox"
cat > "$HOME/.config/openbox/menu.xml" << 'MENU'
<?xml version="1.0" encoding="UTF-8"?>
<openbox_menu>
  <menu id="root-menu" label="Dracon OS">

    <item label="App Launcher">
      <action name="Execute">
        <command>xterm -bg "#0d1117" -fg "#c9d1d9" -fa Monospace -fs 11 -title "Launcher" -e python3 ~/.dracon/apps/launcher/launcher.py</command>
      </action>
    </item>

    <item label="Terminal">
      <action name="Execute">
        <command>xterm -bg "#0d1117" -fg "#c9d1d9" -fa Monospace -fs 11</command>
      </action>
    </item>

    <separator label="-- Apps --"/>

    <item label="Dracon Store">
      <action name="Execute">
        <command>xterm -bg "#0d1117" -fg "#c9d1d9" -fa Monospace -e python3 ~/.dracon/apps/store/store.py</command>
      </action>
    </item>

    <item label="Calculator">
      <action name="Execute">
        <command>xterm -bg "#0d1117" -fg "#c9d1d9" -fa Monospace -e python3 ~/.dracon/apps/calculator/calc.py</command>
      </action>
    </item>

    <item label="Text Editor">
      <action name="Execute">
        <command>xterm -bg "#0d1117" -fg "#c9d1d9" -fa Monospace -e python3 ~/.dracon/apps/editor/editor.py</command>
      </action>
    </item>

    <item label="System Monitor">
      <action name="Execute">
        <command>xterm -bg "#0d1117" -fg "#c9d1d9" -fa Monospace -e python3 ~/.dracon/bin/monitor.py</command>
      </action>
    </item>

    <separator label="-- Settings --"/>

    <item label="Settings">
      <action name="Execute">
        <command>xterm -bg "#0d1117" -fg "#c9d1d9" -fa Monospace -e python3 ~/.dracon/apps/settings/settings.py</command>
      </action>
    </item>

    <item label="Volume">
      <action name="Execute">
        <command>xterm -bg "#0d1117" -fg "#c9d1d9" -fa Monospace -e bash ~/.dracon/bin/volume.sh</command>
      </action>
    </item>

    <separator/>

    <item label="Install .drapp">
      <action name="Execute">
        <command>xterm -bg "#0d1117" -fg "#c9d1d9" -fa Monospace -e bash -c "echo 'drapp install <arquivo.drapp>'; bash"</command>
      </action>
    </item>

    <item label="Restart Desktop">
      <action name="Execute">
        <command>bash ~/.dracon/bin/desktop.sh</command>
      </action>
    </item>

    <item label="Stop Dracon OS">
      <action name="Execute">
        <command>dracon stop</command>
      </action>
    </item>

  </menu>
</openbox_menu>
MENU
log_ok "Desktop menu updated"

log_step "Updating version"
echo "DRACON_VERSION=1.2.0" > "$DRACON_HOME/config/version"
log_ok "Version → 1.2.0"

echo ""
echo -e "  ${G}╔════════════════════════════════════════════╗${NC}"
echo -e "  ${G}║${NC}   ${W}Dracon OS updated to v1.2.0!${NC}             ${G}║${NC}"
echo -e "  ${G}╠════════════════════════════════════════════╣${NC}"
echo -e "  ${G}║${NC}                                            ${G}║${NC}"
echo -e "  ${G}║${NC}  ${R}.drapp${NC} format — native app support       ${G}║${NC}"
echo -e "  ${G}║${NC}  ${R}dracon-launcher${NC} — visual app launcher     ${G}║${NC}"
echo -e "  ${G}║${NC}  ${R}drapp install${NC} — install .drapp files      ${G}║${NC}"
echo -e "  ${G}║${NC}  ${R}drapp run${NC} — run .drapp apps               ${G}║${NC}"
echo -e "  ${G}║${NC}  ${R}Bug fixes${NC} — store, calc, editor           ${G}║${NC}"
echo -e "  ${G}║${NC}  ${R}assets/${NC} — images folder structure         ${G}║${NC}"
echo -e "  ${G}║${NC}                                            ${G}║${NC}"
echo -e "  ${G}║${NC}  ${Y}Restart:${NC} dracon restart                   ${G}║${NC}"
echo -e "  ${G}╚════════════════════════════════════════════╝${NC}"
echo ""
echo -e "  ${DIM}Developer docs: ~/.dracon/dev/DRAPP_SPEC.md${NC}"
echo ""
