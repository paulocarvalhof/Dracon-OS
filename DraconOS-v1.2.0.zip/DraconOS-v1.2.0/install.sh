#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
#   Dracon OS v1.2.0 — Installer
#   Installs from SCRATCH (no v1.0 needed!)
# ============================================================

DRACON_VERSION="1.2.0"
DRACON_DIR="$HOME/.dracon"
DRACON_SRC="$(cd "$(dirname "$0")" && pwd)"

# ─── Colors ────────────────────────────────────────────
R='\033[0;31m'
G='\033[0;32m'
B='\033[0;34m'
C='\033[0;36m'
Y='\033[1;33m'
W='\033[1;37m'
DIM='\033[2m'
NC='\033[0m'

# ─── Banner ─────────────────────────────────────────────
banner() {
  clear
  echo -e "${R}"
  echo '  ██████╗ ██████╗  █████╗  ██████╗ ██████╗ ███╗   ██╗'
  echo '  ██╔══██╗██╔══██╗██╔══██╗██╔════╝██╔═══██╗████╗  ██║'
  echo '  ██║  ██║██████╔╝███████║██║     ██║   ██║██╔██╗ ██║'
  echo '  ██║  ██║██╔══██╗██╔══██║██║     ██║   ██║██║╚██╗██║'
  echo '  ██████╔╝██║  ██║██║  ██║╚██████╗╚██████╔╝██║ ╚████║'
  echo '  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝ ╚═════╝ ╚═╝  ╚═══╝'
  echo -e "${DIM}${W}                  O  S  ${R}v${DRACON_VERSION}${NC}"
  echo ""
  echo -e "${DIM}Alpine-inspired desktop OS for Termux + VNC${NC}"
  echo -e "${DIM}──────────────────────────────────────────${NC}"
  echo ""
}

# ─── Logging ────────────────────────────────────────────
log_info()  { echo -e "  ${C}[INFO]${NC}  $1"; }
log_ok()    { echo -e "  ${G}[ OK ]${NC}  $1"; }
log_warn()  { echo -e "  ${Y}[WARN]${NC}  $1"; }
log_err()   { echo -e "  ${R}[FAIL]${NC}  $1"; }
log_step()  { echo -e "\n  ${W}══ $1 ══${NC}"; }

# ─── Check environment ─────────────────────────────────
check_env() {
  log_step "Checking Environment"

  if [ ! -d "/data/data/com.termux" ]; then
    log_warn "Not running inside Termux — continuing anyway"
  else
    log_ok "Termux environment detected"
  fi

  if ! command -v pkg &>/dev/null && ! command -v apt &>/dev/null; then
    log_err "No package manager found (pkg/apt)"
    exit 1
  fi
  log_ok "Package manager found"

  if [ -d "$DRACON_DIR" ]; then
    log_warn "Dracon OS already installed at $DRACON_DIR"
    read -p "  Overwrite? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
      log_info "Installation cancelled"
      exit 0
    fi
    log_info "Backing up old installation..."
    mv "$DRACON_DIR" "$DRACON_DIR.bak.$(date +%Y%m%d_%H%M%S)"
    log_ok "Backup saved"
  fi
}

# ─── Install system dependencies ────────────────────────
install_deps() {
  log_step "Installing System Dependencies"

  PKGS=(
    x11-repo
    tigervnc
    openbox
    xterm
    python
    python-pip
    feh
    tint2
    rofi
    wget
    curl
    git
    unzip
    jq
  )

  log_info "Updating package repositories..."
  pkg update -y &>/dev/null
  log_ok "Repositories updated"

  for pkg in "${PKGS[@]}"; do
    if command -v dpkg &>/dev/null; then
      # Debian-based
      if dpkg -l | grep -q "^ii  $pkg"; then
        echo -ne "  ${DIM}✓ $pkg (already installed)${NC}\r"
      else
        echo -ne "  ${DIM}Installing ${pkg}...${NC}\r"
        pkg install -y "$pkg" &>/dev/null 2>&1
        echo -e "  ${G}✓${NC} $pkg                    "
      fi
    else
      # Fallback
      echo -ne "  ${DIM}Installing ${pkg}...${NC}\r"
      pkg install -y "$pkg" &>/dev/null 2>&1
      echo -e "  ${G}✓${NC} $pkg                    "
    fi
  done

  log_info "Installing Python packages..."
  pip install pillow psutil pynput --quiet 2>/dev/null || true
  log_ok "Python packages installed"
}

# ─── Create directory structure ─────────────────────────
create_structure() {
  log_step "Creating Directory Structure"

  mkdir -p "$DRACON_DIR"/{bin,config,themes/{alpine,dark,ocean,forest},logs,packages,cache,wallpapers,apps/{launcher,store,settings,calculator,editor,notif,installed},dev,assets/images/{boot,wallpapers,icons,ui}}

  log_ok "Directory structure created at $DRACON_DIR"
}

# ─── Copy files ─────────────────────────────────────────
copy_files() {
  log_step "Installing Dracon OS Files"

  # Core files
  cp "$DRACON_SRC/core"/*.sh        "$DRACON_DIR/bin/" 2>/dev/null || true
  cp "$DRACON_SRC/desktop"/*.sh     "$DRACON_DIR/bin/" 2>/dev/null || true
  cp "$DRACON_SRC/desktop"/*.py     "$DRACON_DIR/bin/" 2>/dev/null || true
  
  # Apps
  cp -r "$DRACON_SRC/apps"/*        "$DRACON_DIR/apps/" 2>/dev/null || true
  
  # Themes & config
  cp -r "$DRACON_SRC/themes"/*      "$DRACON_DIR/themes/" 2>/dev/null || true
  cp "$DRACON_SRC/config"/*         "$DRACON_DIR/config/" 2>/dev/null || true
  
  # Dev tools
  cp -r "$DRACON_SRC/dev"/*         "$DRACON_DIR/dev/" 2>/dev/null || true
  
  # Assets
  cp -r "$DRACON_SRC/assets"/*      "$DRACON_DIR/assets/" 2>/dev/null || true

  # Make scripts executable
  chmod +x "$DRACON_DIR/bin/"*.sh 2>/dev/null || true
  chmod +x "$DRACON_DIR/bin/"*.py 2>/dev/null || true
  chmod +x "$DRACON_DIR/apps/"**/*.py 2>/dev/null || true
  chmod +x "$DRACON_DIR/dev/"**/*.py 2>/dev/null || true

  log_ok "Dracon OS files installed"
}

# ─── Register global commands ────────────────────────────
register_commands() {
  log_step "Registering Global Commands"

  # dracon main command
  ln -sf "$DRACON_DIR/bin/boot.sh"   "$PREFIX/bin/dracon"         2>/dev/null || true
  ln -sf "$DRACON_DIR/bin/boot.sh"   "/usr/local/bin/dracon"      2>/dev/null || true
  chmod +x "$PREFIX/bin/dracon" 2>/dev/null || true
  log_ok "dracon — boot controller"

  # dpm (package manager)
  if [ -f "$DRACON_DIR/bin/dpm.sh" ]; then
    ln -sf "$DRACON_DIR/bin/dpm.sh"   "$PREFIX/bin/dpm"           2>/dev/null || true
    chmod +x "$PREFIX/bin/dpm" 2>/dev/null || true
    log_ok "dpm — package manager"
  fi

  # drapp (app format)
  if [ -f "$DRACON_DIR/bin/drapp.sh" ]; then
    ln -sf "$DRACON_DIR/bin/drapp.sh" "$PREFIX/bin/drapp"         2>/dev/null || true
    chmod +x "$PREFIX/bin/drapp" 2>/dev/null || true
    log_ok "drapp — .drapp installer"
  fi

  # Launcher
  if [ -f "$DRACON_DIR/apps/launcher/launcher.py" ]; then
    ln -sf "$DRACON_DIR/apps/launcher/launcher.py" "$PREFIX/bin/dracon-launcher" 2>/dev/null || true
    chmod +x "$PREFIX/bin/dracon-launcher" 2>/dev/null || true
    log_ok "dracon-launcher — visual app launcher"
  fi

  # System apps shortcuts
  ln -sf "$DRACON_DIR/apps/store/store.py"     "$PREFIX/bin/dracon-store"     2>/dev/null || true
  ln -sf "$DRACON_DIR/apps/settings/settings.py" "$PREFIX/bin/dracon-settings" 2>/dev/null || true
  ln -sf "$DRACON_DIR/apps/calculator/calc.py" "$PREFIX/bin/dracon-calc"      2>/dev/null || true
  ln -sf "$DRACON_DIR/apps/editor/editor.py"   "$PREFIX/bin/dracon-edit"      2>/dev/null || true
  
  chmod +x "$PREFIX/bin/dracon-"* 2>/dev/null || true
}

# ─── Configure VNC ──────────────────────────────────────
configure_vnc() {
  log_step "Configuring VNC"

  mkdir -p "$HOME/.vnc"

  # Create xstartup script
  cat > "$HOME/.vnc/xstartup" << 'XSTARTUP'
#!/bin/bash
export DRACON_HOME="$HOME/.dracon"
export DISPLAY=:1
export XDG_RUNTIME_DIR="$HOME/.dracon/runtime"
mkdir -p "$XDG_RUNTIME_DIR"

# Show boot animation
bash "$DRACON_HOME/bin/bootscreen.sh" 2>/dev/null || true

# Launch desktop environment
bash "$DRACON_HOME/bin/desktop.sh" &
sleep 0.5

# Launch panel
bash "$DRACON_HOME/bin/panel.sh" &
sleep 0.5

# Launch Openbox window manager
exec openbox --config-file "$DRACON_HOME/config/openbox.xml"
XSTARTUP

  chmod +x "$HOME/.vnc/xstartup"
  log_ok "VNC xstartup configured"

  # Set VNC password
  echo ""
  log_info "Set your VNC password (minimum 6 characters):"
  vncpasswd
  log_ok "VNC password saved"
}

# ─── Generate wallpapers ────────────────────────────────
generate_wallpapers() {
  log_step "Generating Wallpapers"

  if command -v python3 &>/dev/null; then
    for theme in alpine dark ocean forest; do
      echo -ne "  ${DIM}Generating ${theme} wallpaper...${NC}\r"
      python3 "$DRACON_DIR/bin/wallpaper.py" \
        "$DRACON_DIR/themes/$theme/wallpaper.png" "$theme" 2>/dev/null &
    done
    wait
    log_ok "All wallpapers generated (alpine, dark, ocean, forest)"
  else
    log_warn "Python3 not found — wallpapers will be generated on first boot"
  fi
}

# ─── Initialize databases ────────────────────────────────
init_databases() {
  log_step "Initializing Databases"

  # Package manager database
  echo '{"packages":{}}' > "$DRACON_DIR/packages/installed.json"
  log_ok "Package database initialized"

  # .drapp database
  echo '{"apps":{}}' > "$DRACON_DIR/packages/drapp.json"
  log_ok ".drapp database initialized"

  # Version file
  echo "DRACON_VERSION=$DRACON_VERSION" > "$DRACON_DIR/config/version"
  log_ok "Version set to $DRACON_VERSION"
}

# ─── Create desktop menu ────────────────────────────────
create_desktop_menu() {
  log_step "Creating Desktop Menu"

  mkdir -p "$HOME/.config/openbox"

  cat > "$HOME/.config/openbox/menu.xml" << 'MENU'
<?xml version="1.0" encoding="UTF-8"?>
<openbox_menu>
  <menu id="root-menu" label="Dracon OS v1.2.0">

    <item label="App Launcher">
      <action name="Execute">
        <command>xterm -bg "#0d1117" -fg "#c9d1d9" -fa Monospace -fs 11 -title "Launcher" -e python3 ~/.dracon/apps/launcher/launcher.py</command>
      </action>
    </item>

    <item label="Terminal">
      <action name="Execute">
        <command>xterm -bg "#0d1117" -fg "#c9d1d9" -fa Monospace -fs 11</command>
      </action>
    </item>

    <separator label="-- Applications --"/>

    <item label="Dracon Store">
      <action name="Execute">
        <command>xterm -bg "#0d1117" -fg "#c9d1d9" -title "Store" -e python3 ~/.dracon/apps/store/store.py</command>
      </action>
    </item>

    <item label="Calculator">
      <action name="Execute">
        <command>xterm -bg "#0d1117" -fg "#c9d1d9" -title "Calculator" -e python3 ~/.dracon/apps/calculator/calc.py</command>
      </action>
    </item>

    <item label="Text Editor">
      <action name="Execute">
        <command>xterm -bg "#0d1117" -fg "#c9d1d9" -title "Editor" -e python3 ~/.dracon/apps/editor/editor.py</command>
      </action>
    </item>

    <item label="System Monitor">
      <action name="Execute">
        <command>xterm -bg "#0d1117" -fg "#c9d1d9" -title "Monitor" -e python3 ~/.dracon/bin/monitor.py</command>
      </action>
    </item>

    <separator label="-- Settings --"/>

    <item label="Settings">
      <action name="Execute">
        <command>xterm -bg "#0d1117" -fg "#c9d1d9" -title "Settings" -e python3 ~/.dracon/apps/settings/settings.py</command>
      </action>
    </item>

    <item label="Volume">
      <action name="Execute">
        <command>xterm -bg "#0d1117" -fg "#c9d1d9" -title "Volume" -e bash ~/.dracon/bin/volume.sh</command>
      </action>
    </item>

    <item label="Install App">
      <action name="Execute">
        <command>xterm -bg "#0d1117" -fg "#c9d1d9" -title "Install App" -e bash -c "echo '=== Dracon App Installer ==='; echo 'Usage: drapp install <file.drapp>'; echo 'Or: drapp run <app-id>'; bash"</command>
      </action>
    </item>

    <separator/>

    <item label="Restart Desktop">
      <action name="Execute">
        <command>bash ~/.dracon/bin/desktop.sh</command>
      </action>
    </item>

    <item label="Stop Dracon OS">
      <action name="Execute">
        <command>dracon stop</command>
      </action>
    </item>

  </menu>
</openbox_menu>
MENU
  log_ok "Desktop menu created"
}

# ─── Final message ───────────────────────────────────────
finish() {
  log_step "Installation Complete"
  echo ""
  echo -e "  ${G}╔════════════════════════════════════════════╗${NC}"
  echo -e "  ${G}║${NC}  ${W}Dracon OS v${DRACON_VERSION} installed successfully!${NC}         ${G}║${NC}"
  echo -e "  ${G}╠════════════════════════════════════════════╣${NC}"
  echo -e "  ${G}║${NC}                                            ${G}║${NC}"
  echo -e "  ${G}║${NC}  ${C}Quick start:${NC}                            ${G}║${NC}"
  echo -e "  ${G}║${NC}    ${Y}dracon start${NC}     — Start the OS       ${G}║${NC}"
  echo -e "  ${G}║${NC}    ${Y}dracon stop${NC}      — Stop the OS        ${G}║${NC}"
  echo -e "  ${G}║${NC}    ${Y}dracon restart${NC}   — Restart           ${G}║${NC}"
  echo -e "  ${G}║${NC}    ${Y}dracon status${NC}    — Show status       ${G}║${NC}"
  echo -e "  ${G}║${NC}                                            ${G}║${NC}"
  echo -e "  ${G}║${NC}  ${C}VNC Connection:${NC}                       ${G}║${NC}"
  echo -e "  ${G}║${NC}    RealVNC Viewer → localhost:5901          ${G}║${NC}"
  echo -e "  ${G}║${NC}    Use your VNC password                    ${G}║${NC}"
  echo -e "  ${G}║${NC}                                            ${G}║${NC}"
  echo -e "  ${G}║${NC}  ${C}Developer Guide:${NC}                      ${G}║${NC}"
  echo -e "  ${G}║${NC}    ~/.dracon/dev/DRAPP_SPEC.md             ${G}║${NC}"
  echo -e "  ${G}║${NC}                                            ${G}║${NC}"
  echo -e "  ${G}╚════════════════════════════════════════════╝${NC}"
  echo ""
  echo -e "  ${DIM}Ready? Run: ${Y}dracon start${NC}"
  echo ""
}

# ─── Entry Point ────────────────────────────────────────
main() {
  banner
  check_env
  install_deps
  create_structure
  copy_files
  register_commands
  configure_vnc
  init_databases
  create_desktop_menu
  generate_wallpapers
  finish
}

main "$@"
