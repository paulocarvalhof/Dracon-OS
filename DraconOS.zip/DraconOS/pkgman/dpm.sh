#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
#   Dracon OS — Package Manager (dpm)
#   pkgman/dpm.sh
# ============================================================

DRACON_HOME="$HOME/.dracon"
DPM_DIR="$DRACON_HOME/packages"
DPM_CACHE="$DRACON_HOME/cache"
DPM_REPO_FILE="$DRACON_HOME/config/repo.list"
DPM_DB="$DPM_DIR/installed.json"
DPM_VERSION="1.0.0"

mkdir -p "$DPM_DIR" "$DPM_CACHE"

# ─── Colors ────────────────────────────────────────────────
R='\033[0;31m'
G='\033[0;32m'
C='\033[0;36m'
Y='\033[1;33m'
W='\033[1;37m'
DIM='\033[2m'
NC='\033[0m'

# ─── Init DB ─────────────────────────────────────────────────
init_db() {
  if [ ! -f "$DPM_DB" ]; then
    echo '{"packages":{}}' > "$DPM_DB"
  fi
}

# ─── Banner ──────────────────────────────────────────────────
dpm_banner() {
  echo -e "${R}  dpm${NC} — ${W}Dracon Package Manager${NC} ${DIM}v${DPM_VERSION}${NC}"
  echo -e "  ${DIM}──────────────────────────────────────${NC}"
}

# ─── Progress bar ────────────────────────────────────────────
progress() {
  local msg="$1"
  local i=0
  local chars=('⣾' '⣽' '⣻' '⢿' '⡿' '⣟' '⣯' '⣷')
  while kill -0 $! 2>/dev/null; do
    echo -ne "  ${C}${chars[$i]}${NC}  ${msg}...\r"
    i=$(( (i + 1) % 8 ))
    sleep 0.1
  done
  echo -e "  ${G}✓${NC}  ${msg}       "
}

# ─── Is pkg installed? ───────────────────────────────────────
is_installed() {
  local pkg="$1"
  python3 -c "
import json, sys
db = json.load(open('$DPM_DB'))
sys.exit(0 if '$pkg' in db['packages'] else 1)
" 2>/dev/null
}

# ─── Mark installed ──────────────────────────────────────────
mark_installed() {
  local pkg="$1"
  local ver="$2"
  python3 - <<PYEOF
import json, datetime
try:
    db = json.load(open('$DPM_DB'))
except:
    db = {"packages": {}}
db['packages']['$pkg'] = {
    "version": "$ver",
    "installed_at": datetime.datetime.now().isoformat()
}
json.dump(db, open('$DPM_DB', 'w'), indent=2)
PYEOF
}

# ─── Mark removed ────────────────────────────────────────────
mark_removed() {
  local pkg="$1"
  python3 - <<PYEOF
import json
try:
    db = json.load(open('$DPM_DB'))
    db['packages'].pop('$pkg', None)
    json.dump(db, open('$DPM_DB', 'w'), indent=2)
except:
    pass
PYEOF
}

# ─── Resolve package to system pkg ───────────────────────────
# Maps Dracon package names → actual system packages
resolve_pkg() {
  local pkg="$1"
  # Load from repo.list or use direct mapping
  case "$pkg" in
    browser|firefox)   echo "firefox" ;;
    editor|vscode)     echo "code-server" ;;
    files|thunar)      echo "thunar" ;;
    monitor|htop)      echo "htop" ;;
    image|eog)         echo "eog" ;;
    calc|galculator)   echo "galculator" ;;
    music|vlc)         echo "vlc" ;;
    git)               echo "git" ;;
    python)            echo "python" ;;
    node|nodejs)       echo "nodejs" ;;
    neofetch)          echo "neofetch" ;;
    screenshooter)     echo "scrot" ;;
    term|terminal)     echo "xterm" ;;
    vim)               echo "vim" ;;
    tmux)              echo "tmux" ;;
    *)                 echo "$pkg" ;;   # pass-through
  esac
}

# ─── Install ─────────────────────────────────────────────────
cmd_install() {
  dpm_banner
  shift

  if [ $# -eq 0 ]; then
    echo -e "  ${R}Usage: dpm install <package> [package2 ...]${NC}"
    exit 1
  fi

  for pkg in "$@"; do
    echo -e "\n  ${W}Package:${NC} $pkg"

    if is_installed "$pkg"; then
      echo -e "  ${Y}⚠${NC}  Already installed — skipping"
      continue
    fi

    sys_pkg=$(resolve_pkg "$pkg")
    echo -e "  ${DIM}Resolves to: $sys_pkg${NC}"

    # Install via pkg (Termux) or apt
    if command -v pkg &>/dev/null; then
      pkg install -y "$sys_pkg" &>/dev/null &
    else
      apt install -y "$sys_pkg" &>/dev/null &
    fi
    progress "Installing $pkg"

    mark_installed "$pkg" "latest"
    echo -e "  ${G}✓ $pkg installed successfully${NC}"
  done
  echo ""
}

# ─── Remove ──────────────────────────────────────────────────
cmd_remove() {
  dpm_banner
  shift

  if [ $# -eq 0 ]; then
    echo -e "  ${R}Usage: dpm remove <package>  ${NC}"
    exit 1
  fi

  for pkg in "$@"; do
    echo -e "\n  ${W}Package:${NC} $pkg"

    if ! is_installed "$pkg"; then
      echo -e "  ${Y}⚠${NC}  Not installed"
      continue
    fi

    sys_pkg=$(resolve_pkg "$pkg")

    if command -v pkg &>/dev/null; then
      pkg uninstall -y "$sys_pkg" &>/dev/null &
    else
      apt remove -y "$sys_pkg" &>/dev/null &
    fi
    progress "Removing $pkg"

    mark_removed "$pkg"
    echo -e "  ${G}✓ $pkg removed${NC}"
  done
  echo ""
}

# ─── List ────────────────────────────────────────────────────
cmd_list() {
  dpm_banner
  echo -e "  ${W}Installed Packages${NC}\n"

  python3 - <<'PYEOF'
import json, os
db_path = os.path.expanduser("~/.dracon/packages/installed.json")
try:
    db = json.load(open(db_path))
    pkgs = db.get("packages", {})
    if not pkgs:
        print("  \033[2mNo packages installed yet.\033[0m")
    else:
        for name, info in sorted(pkgs.items()):
            ver = info.get("version", "?")
            date = info.get("installed_at", "")[:10]
            print(f"  \033[0;32m✓\033[0m  {name:<20} {ver:<10} \033[2m{date}\033[0m")
except Exception as e:
    print(f"  Error reading package database: {e}")
PYEOF
  echo ""
}

# ─── Search ──────────────────────────────────────────────────
cmd_search() {
  dpm_banner
  local query="${2:-}"

  if [ -z "$query" ]; then
    echo -e "  ${R}Usage: dpm search <query>${NC}"
    exit 1
  fi

  echo -e "  ${W}Search results for:${NC} ${C}$query${NC}\n"

  # Built-in package catalog
  declare -A CATALOG
  CATALOG["browser"]="Web browser (Firefox)"
  CATALOG["editor"]="Code editor (VSCode server)"
  CATALOG["files"]="File manager (Thunar)"
  CATALOG["monitor"]="System monitor (htop)"
  CATALOG["music"]="Media player (VLC)"
  CATALOG["git"]="Git version control"
  CATALOG["python"]="Python 3 runtime"
  CATALOG["node"]="Node.js runtime"
  CATALOG["neofetch"]="System info display"
  CATALOG["vim"]="Terminal text editor"
  CATALOG["tmux"]="Terminal multiplexer"
  CATALOG["screenshooter"]="Screenshot tool"
  CATALOG["term"]="Terminal emulator (xterm)"
  CATALOG["calc"]="Calculator app"
  CATALOG["image"]="Image viewer"

  found=0
  for pkg in "${!CATALOG[@]}"; do
    if [[ "$pkg" == *"$query"* ]] || [[ "${CATALOG[$pkg]}" == *"$query"* ]]; then
      echo -e "  ${C}$pkg${NC}  —  ${DIM}${CATALOG[$pkg]}${NC}"
      found=1
    fi
  done

  if [ $found -eq 0 ]; then
    echo -e "  ${DIM}No results found for '$query'${NC}"
  fi
  echo ""
}

# ─── Update package list ─────────────────────────────────────
cmd_update() {
  dpm_banner
  echo -e "  ${C}Syncing package repositories...${NC}"
  pkg update -y &>/dev/null &
  progress "Updating repositories"
  echo -e "  ${G}✓ Repositories up to date${NC}\n"
}

# ─── Info ────────────────────────────────────────────────────
cmd_info() {
  dpm_banner
  local pkg="${2:-}"
  if is_installed "$pkg"; then
    echo -e "  ${G}Status:${NC} Installed"
  else
    echo -e "  ${Y}Status:${NC} Not installed"
  fi

  sys_pkg=$(resolve_pkg "$pkg")
  echo -e "  ${C}System package:${NC} $sys_pkg"
  echo ""
}

# ─── TUI Mode ────────────────────────────────────────────────
cmd_tui() {
  python3 "$DRACON_HOME/bin/dpm_tui.py" 2>/dev/null || {
    echo -e "  ${Y}TUI not available — use CLI mode${NC}"
    cmd_help
  }
}

# ─── Help ────────────────────────────────────────────────────
cmd_help() {
  dpm_banner
  echo -e "  ${W}Usage:${NC} dpm <command> [args]"
  echo ""
  echo -e "  ${C}Commands:${NC}"
  echo -e "    ${G}install${NC} <pkg...>   Install packages"
  echo -e "    ${G}remove${NC}  <pkg...>   Remove packages"
  echo -e "    ${G}list${NC}               List installed packages"
  echo -e "    ${G}search${NC}  <query>    Search package catalog"
  echo -e "    ${G}update${NC}             Update package list"
  echo -e "    ${G}info${NC}    <pkg>      Show package info"
  echo -e "    ${G}help${NC}               Show this help"
  echo ""
  echo -e "  ${DIM}Example: dpm install browser git python${NC}"
  echo ""
}

# ─── Entry ───────────────────────────────────────────────────
init_db
case "${1:-help}" in
  install)  cmd_install "$@"  ;;
  remove)   cmd_remove  "$@"  ;;
  list)     cmd_list          ;;
  search)   cmd_search  "$@"  ;;
  update)   cmd_update        ;;
  info)     cmd_info    "$@"  ;;
  --tui)    cmd_tui           ;;
  help|--help|-h) cmd_help   ;;
  *)
    echo -e "  ${R}Unknown command: $1${NC}"
    cmd_help
    exit 1
    ;;
esac
