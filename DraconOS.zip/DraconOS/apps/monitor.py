#!/usr/bin/env python3
# ============================================================
#   Dracon OS — System Monitor
#   apps/monitor.py
# ============================================================

import os
import sys
import time
import curses

try:
    import psutil
except ImportError:
    os.system("pip install psutil --quiet")
    import psutil


def bytes_to_human(n):
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if n < 1024:
            return f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} PB"


def bar(value, width=20, fill="█", empty="░"):
    filled = int(value / 100 * width)
    return fill * filled + empty * (width - filled)


def draw(stdscr):
    curses.start_color()
    curses.init_pair(1, curses.COLOR_RED, curses.COLOR_BLACK)      # accent
    curses.init_pair(2, curses.COLOR_GREEN, curses.COLOR_BLACK)    # ok
    curses.init_pair(3, curses.COLOR_YELLOW, curses.COLOR_BLACK)   # warn
    curses.init_pair(4, curses.COLOR_CYAN, curses.COLOR_BLACK)     # info
    curses.init_pair(5, curses.COLOR_WHITE, curses.COLOR_BLACK)    # normal
    curses.init_pair(6, curses.COLOR_BLACK, curses.COLOR_RED)      # header bg

    curses.curs_set(0)
    stdscr.nodelay(True)

    RED    = curses.color_pair(1) | curses.A_BOLD
    GREEN  = curses.color_pair(2)
    YELLOW = curses.color_pair(3)
    CYAN   = curses.color_pair(4)
    WHITE  = curses.color_pair(5)
    DIM    = curses.color_pair(5) | curses.A_DIM
    BOLD   = curses.color_pair(5) | curses.A_BOLD

    while True:
        stdscr.erase()
        h, w = stdscr.getmaxyx()

        # ── Header ──
        header = "  DRACON OS — SYSTEM MONITOR  "
        pad = " " * ((w - len(header)) // 2)
        stdscr.addstr(0, 0, pad + header + pad, curses.color_pair(6) | curses.A_BOLD)
        stdscr.addstr(1, 0, "─" * w, DIM)

        row = 3

        # ── CPU ──
        cpu = psutil.cpu_percent(interval=None)
        cpu_count = psutil.cpu_count()
        col = RED if cpu > 80 else (YELLOW if cpu > 50 else GREEN)

        stdscr.addstr(row, 2, "CPU", BOLD)
        stdscr.addstr(row, 8, f"[{bar(cpu)}]", col)
        stdscr.addstr(row, 32, f"{cpu:5.1f}%  {cpu_count} cores", WHITE)
        row += 2

        # ── Per-core ──
        per_core = psutil.cpu_percent(percpu=True, interval=None)
        stdscr.addstr(row, 2, "Cores", DIM)
        x = 10
        for i, c in enumerate(per_core[:8]):
            c_col = RED if c > 80 else (YELLOW if c > 50 else GREEN)
            stdscr.addstr(row, x, f"{c:4.0f}%", c_col)
            x += 7
        row += 2

        # ── Memory ──
        mem = psutil.virtual_memory()
        mem_pct = mem.percent
        mem_col = RED if mem_pct > 85 else (YELLOW if mem_pct > 60 else GREEN)

        stdscr.addstr(row, 2, "RAM", BOLD)
        stdscr.addstr(row, 8, f"[{bar(mem_pct)}]", mem_col)
        stdscr.addstr(row, 32,
            f"{mem_pct:5.1f}%  {bytes_to_human(mem.used)}/{bytes_to_human(mem.total)}",
            WHITE)
        row += 2

        # ── Swap ──
        swap = psutil.swap_memory()
        if swap.total > 0:
            stdscr.addstr(row, 2, "SWAP", BOLD)
            stdscr.addstr(row, 8, f"[{bar(swap.percent)}]",
                          RED if swap.percent > 50 else GREEN)
            stdscr.addstr(row, 32,
                f"{swap.percent:5.1f}%  {bytes_to_human(swap.used)}/{bytes_to_human(swap.total)}",
                WHITE)
            row += 2

        # ── Disk ──
        try:
            disk = psutil.disk_usage("/")
            stdscr.addstr(row, 2, "DISK", BOLD)
            stdscr.addstr(row, 8, f"[{bar(disk.percent)}]",
                          RED if disk.percent > 90 else GREEN)
            stdscr.addstr(row, 32,
                f"{disk.percent:5.1f}%  {bytes_to_human(disk.used)}/{bytes_to_human(disk.total)}",
                WHITE)
            row += 2
        except Exception:
            pass

        # ── Network ──
        try:
            net = psutil.net_io_counters()
            stdscr.addstr(row, 2, "NET", BOLD)
            stdscr.addstr(row, 8,
                f"▲ {bytes_to_human(net.bytes_sent):>10}   ▼ {bytes_to_human(net.bytes_recv):>10}",
                CYAN)
            row += 2
        except Exception:
            pass

        # ── Processes ──
        stdscr.addstr(row, 0, "─" * w, DIM)
        row += 1
        stdscr.addstr(row, 2, f"{'PID':<7} {'NAME':<20} {'CPU%':>6} {'MEM%':>6} {'STATUS':<10}", BOLD)
        row += 1
        stdscr.addstr(row, 0, "─" * w, DIM)
        row += 1

        procs = []
        for p in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_percent', 'status']):
            try:
                procs.append(p.info)
            except Exception:
                pass

        procs.sort(key=lambda x: x.get('cpu_percent') or 0, reverse=True)

        for p in procs[:min(10, h - row - 2)]:
            pid    = str(p.get('pid', '?'))
            name   = (p.get('name') or '?')[:20]
            cpu_p  = p.get('cpu_percent') or 0
            mem_p  = p.get('memory_percent') or 0
            status = p.get('status') or '?'

            row_col = RED if cpu_p > 50 else WHITE
            stdscr.addstr(row, 2,
                f"{pid:<7} {name:<20} {cpu_p:>5.1f}% {mem_p:>5.1f}% {status:<10}",
                row_col)
            row += 1
            if row >= h - 2:
                break

        # ── Footer ──
        stdscr.addstr(h - 1, 0, "─" * w, DIM)
        stdscr.addstr(h - 1, 2, " q: quit  r: refresh ", DIM)
        stdscr.addstr(h - 1, w - 30,
            time.strftime(" Dracon OS  %H:%M:%S "), DIM)

        stdscr.refresh()

        # Input
        key = stdscr.getch()
        if key in (ord('q'), ord('Q'), 27):
            break

        time.sleep(1.5)
        # Kick off next cpu sample
        psutil.cpu_percent(interval=None)
        psutil.cpu_percent(percpu=True, interval=None)


def main():
    try:
        curses.wrapper(draw)
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
