#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
#   Dracon OS — Desktop Environment
#   desktop/desktop.sh
# ============================================================

DRACON_HOME="$HOME/.dracon"
THEME_DIR="$DRACON_HOME/themes/alpine"

source "$DRACON_HOME/config/dracon.conf" 2>/dev/null

export DISPLAY="${DISPLAY:-:1}"

# ─── Wallpaper ───────────────────────────────────────────────
setup_wallpaper() {
  WALLPAPER="${DRACON_WALLPAPER:-$THEME_DIR/wallpaper.png}"

  if [ -f "$WALLPAPER" ]; then
    feh --bg-fill "$WALLPAPER" 2>/dev/null &
  else
    # Generate wallpaper with Python if image not found
    python3 "$DRACON_HOME/bin/wallpaper.py" "$WALLPAPER" 2>/dev/null
    feh --bg-fill "$WALLPAPER" 2>/dev/null &
  fi
}

# ─── Compositor (basic transparency) ─────────────────────────
setup_compositor() {
  if command -v picom &>/dev/null; then
    picom --config "$THEME_DIR/picom.conf" -b 2>/dev/null
  elif command -v compton &>/dev/null; then
    compton -b 2>/dev/null
  fi
}

# ─── Right-click desktop menu ─────────────────────────────────
setup_obmenu() {
  mkdir -p "$HOME/.config/openbox"
  cat > "$HOME/.config/openbox/menu.xml" << 'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<openbox_menu>
  <menu id="root-menu" label="Dracon OS">

    <item label="Terminal">
      <action name="Execute"><command>xterm -bg "#0d1117" -fg "#c9d1d9" -fa "Monospace" -fs 11</command></action>
    </item>

    <item label="File Manager">
      <action name="Execute"><command>bash ~/.dracon/apps/fileman.sh</command></action>
    </item>

    <separator/>

    <menu id="settings-menu" label="Settings">
      <item label="Change Wallpaper">
        <action name="Execute"><command>bash ~/.dracon/bin/wallpaper.sh</command></action>
      </item>
      <item label="Resolution">
        <action name="Execute"><command>xterm -e bash ~/.dracon/bin/resolution.sh</command></action>
      </item>
      <item label="System Info">
        <action name="Execute"><command>xterm -e python3 ~/.dracon/bin/sysinfo.py</command></action>
      </item>
    </menu>

    <menu id="apps-menu" label="Applications">
      <item label="Package Manager (dpm)">
        <action name="Execute"><command>xterm -e dpm --tui</command></action>
      </item>
      <item label="Text Editor">
        <action name="Execute"><command>xterm -e nano</command></action>
      </item>
      <item label="System Monitor">
        <action name="Execute"><command>xterm -e python3 ~/.dracon/apps/monitor.py</command></action>
      </item>
    </menu>

    <separator/>

    <item label="Restart Desktop">
      <action name="Execute"><command>bash ~/.dracon/bin/desktop.sh</command></action>
    </item>

    <item label="Stop Dracon OS">
      <action name="Execute"><command>dracon stop</command></action>
    </item>

  </menu>
</openbox_menu>
EOF
}

# ─── Autostart apps ──────────────────────────────────────────
autostart() {
  # Launch panel
  pkill tint2 2>/dev/null
  sleep 0.5
  tint2 -c "$THEME_DIR/tint2rc" &>/dev/null &

  # Launch app launcher daemon
  if command -v rofi &>/dev/null; then
    : # rofi launched on demand via keybind
  fi
}

# ─── Main ────────────────────────────────────────────────────
main() {
  setup_wallpaper
  setup_compositor
  setup_obmenu
  autostart
}

main "$@"
