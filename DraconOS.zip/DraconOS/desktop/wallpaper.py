#!/usr/bin/env python3
# ============================================================
#   Dracon OS — Wallpaper Generator
#   desktop/wallpaper.py
# ============================================================

import sys
import os
import math

try:
    from PIL import Image, ImageDraw, ImageFont
except ImportError:
    os.system("pip install pillow --quiet")
    from PIL import Image, ImageDraw, ImageFont


def generate_wallpaper(output_path: str, width: int = 1280, height: int = 720):
    """Generate the Dracon OS Alpine-inspired wallpaper."""

    img = Image.new("RGB", (width, height), color="#0d1117")
    draw = ImageDraw.Draw(img)

    # ── Background gradient (dark navy to near-black) ──
    for y in range(height):
        ratio = y / height
        r = int(13 + (8 - 13) * ratio)
        g = int(17 + (10 - 17) * ratio)
        b = int(23 + (18 - 23) * ratio)
        draw.line([(0, y), (width, y)], fill=(r, g, b))

    # ── Grid lines (subtle) ──
    grid_color = (255, 255, 255, 12)
    grid_img = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    grid_draw = ImageDraw.Draw(grid_img)

    for x in range(0, width, 60):
        grid_draw.line([(x, 0), (x, height)], fill=(255, 255, 255, 8), width=1)
    for y in range(0, height, 60):
        grid_draw.line([(0, y), (width, y)], fill=(255, 255, 255, 8), width=1)

    img = Image.alpha_composite(img.convert("RGBA"), grid_img).convert("RGB")
    draw = ImageDraw.Draw(img)

    # ── Mountain silhouette (Alpine) ──
    mountain_points = []
    peaks = [
        (0, height),
        (width * 0.05, height * 0.75),
        (width * 0.12, height * 0.82),
        (width * 0.20, height * 0.58),   # peak 1
        (width * 0.28, height * 0.70),
        (width * 0.35, height * 0.50),   # peak 2
        (width * 0.42, height * 0.65),
        (width * 0.50, height * 0.42),   # main peak
        (width * 0.58, height * 0.60),
        (width * 0.65, height * 0.48),   # peak 3
        (width * 0.72, height * 0.68),
        (width * 0.80, height * 0.55),   # peak 4
        (width * 0.88, height * 0.72),
        (width * 0.95, height * 0.65),
        (width, height * 0.78),
        (width, height),
    ]
    draw.polygon(peaks, fill="#161b22")

    # ── Snow caps ──
    snow_regions = [
        [(width*0.18, height*0.62), (width*0.20, height*0.58), (width*0.22, height*0.62)],
        [(width*0.33, height*0.54), (width*0.35, height*0.50), (width*0.37, height*0.54)],
        [(width*0.47, height*0.46), (width*0.50, height*0.42), (width*0.53, height*0.46)],
        [(width*0.63, height*0.52), (width*0.65, height*0.48), (width*0.67, height*0.52)],
        [(width*0.78, height*0.59), (width*0.80, height*0.55), (width*0.82, height*0.59)],
    ]
    for snow in snow_regions:
        draw.polygon(snow, fill="#c9d1d9")

    # ── Glow orb (moon / light source) ──
    cx, cy = int(width * 0.75), int(height * 0.22)
    for r in range(120, 0, -1):
        alpha = int(3 * (1 - r / 120))
        col = (248, 60, 60, alpha)
        orb = Image.new("RGBA", (width, height), (0, 0, 0, 0))
        ImageDraw.Draw(orb).ellipse(
            [cx - r, cy - r, cx + r, cy + r], fill=(248, 60, 60, alpha)
        )
        img = Image.alpha_composite(img.convert("RGBA"), orb).convert("RGB")

    draw = ImageDraw.Draw(img)

    # Final moon
    draw.ellipse([cx - 30, cy - 30, cx + 30, cy + 30], fill="#f84c4c")
    draw.ellipse([cx - 22, cy - 22, cx + 22, cy + 22], fill="#ff7070")

    # ── Stars ──
    import random
    random.seed(42)
    for _ in range(200):
        sx = random.randint(0, width)
        sy = random.randint(0, int(height * 0.55))
        brightness = random.randint(80, 200)
        size = random.choice([1, 1, 1, 2])
        draw.ellipse([sx, sy, sx + size, sy + size],
                     fill=(brightness, brightness, brightness))

    # ── Logo text ──
    try:
        font_large = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 48)
        font_small = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 16)
    except Exception:
        font_large = ImageFont.load_default()
        font_small = font_large

    text = "DRACON OS"
    bbox = draw.textbbox((0, 0), text, font=font_large)
    tw = bbox[2] - bbox[0]
    tx = (width - tw) // 2
    ty = int(height * 0.12)

    # Shadow
    draw.text((tx + 2, ty + 2), text, fill=(0, 0, 0, 80), font=font_large)
    draw.text((tx, ty), text, fill="#f84c4c", font=font_large)

    # Subtitle
    sub = "Alpine-inspired Desktop OS"
    sbbox = draw.textbbox((0, 0), sub, font=font_small)
    sw = sbbox[2] - sbbox[0]
    draw.text(((width - sw) // 2, ty + 56), sub, fill="#484f58", font=font_small)

    # ── Bottom bar ──
    draw.rectangle([(0, height - 2), (width, height)], fill="#f84c4c")

    # Save
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    img.save(output_path, "PNG")
    print(f"[wallpaper] Generated: {output_path}")


if __name__ == "__main__":
    output = sys.argv[1] if len(sys.argv) > 1 else os.path.expanduser("~/.dracon/themes/alpine/wallpaper.png")
    generate_wallpaper(output)
