#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
#   Dracon OS — Updater
#   tools/update.sh
# ============================================================

DRACON_HOME="$HOME/.dracon"
REPO_URL="https://github.com/YOUR_USERNAME/DraconOS"

G='\033[0;32m'; R='\033[0;31m'; C='\033[0;36m'; W='\033[1;37m'; DIM='\033[2m'; NC='\033[0m'

echo -e "\n  ${C}Checking for updates...${NC}"

if command -v git &>/dev/null; then
  TMP="/tmp/dracon-update"
  rm -rf "$TMP"
  git clone --depth 1 "$REPO_URL" "$TMP" 2>/dev/null

  if [ $? -eq 0 ]; then
    cp -r "$TMP/core/"*    "$DRACON_HOME/bin/"    2>/dev/null
    cp -r "$TMP/desktop/"* "$DRACON_HOME/bin/"    2>/dev/null
    cp -r "$TMP/apps/"*    "$DRACON_HOME/apps/"   2>/dev/null
    cp -r "$TMP/pkgman/"*  "$DRACON_HOME/bin/"    2>/dev/null
    cp -r "$TMP/themes/"*  "$DRACON_HOME/themes/" 2>/dev/null
    chmod +x "$DRACON_HOME/bin/"*.sh 2>/dev/null
    chmod +x "$DRACON_HOME/bin/"*.py 2>/dev/null
    echo -e "  ${G}✓ Dracon OS updated successfully!${NC}"
    rm -rf "$TMP"
  else
    echo -e "  ${R}✗ Update failed — check your internet connection${NC}"
  fi
else
  pkg install -y git &>/dev/null
  bash "$0"
fi
