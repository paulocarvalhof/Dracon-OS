<div align="center">

```
██████╗ ██████╗  █████╗  ██████╗ ██████╗ ███╗   ██╗
██╔══██╗██╔══██╗██╔══██╗██╔════╝██╔═══██╗████╗  ██║
██║  ██║██████╔╝███████║██║     ██║   ██║██╔██╗ ██║
██║  ██║██╔══██╗██╔══██║██║     ██║   ██║██║╚██╗██║
██████╔╝██║  ██║██║  ██║╚██████╗╚██████╔╝██║ ╚████║
╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝ ╚═════╝ ╚═╝  ╚═══╝
                     O  S
```

**Alpine-inspired Desktop OS for Termux + VNC**

![Version](https://img.shields.io/badge/version-1.0.0-red?style=flat-square)
![Platform](https://img.shields.io/badge/platform-Termux-green?style=flat-square)
![License](https://img.shields.io/badge/license-MIT-blue?style=flat-square)
![Language](https://img.shields.io/badge/built%20with-Bash%20%2B%20Python-yellow?style=flat-square)

</div>

---

## What is Dracon OS?

**Dracon OS** is a custom desktop environment that runs inside **Termux** on Android and streams a full graphical interface through **RealVNC Viewer**. Built from scratch with Bash and Python, it features its own package manager, Alpine-inspired dark theme, window manager, app launcher, and system monitor.

```
Android → Termux → Dracon OS → VNC → RealVNC Viewer
```

---

## Features

- **Full Graphical Desktop** — Openbox WM with custom keybindings and 4 workspaces
- **Alpine Dark Theme** — Minimal, clean aesthetic with red accents (`#f84c4c`)
- **Dracon Package Manager (dpm)** — Install, remove, and search packages with a single command
- **VNC Streaming** — Transmit the desktop to any device via RealVNC Viewer
- **System Monitor** — Real-time CPU, RAM, disk, and process monitor (curses TUI)
- **App Launcher** — Rofi-powered launcher with custom Alpine theme (Super key)
- **Panel** — Tint2 taskbar with clock, workspaces, and systray
- **Wallpaper Generator** — Python-generated Alpine mountain wallpaper at first boot
- **Auto-update** — Pull latest version from GitHub with `dracon update`

---

## Requirements

- **Android** with Termux installed (F-Droid version recommended)
- **RealVNC Viewer** on any device (iOS, Android, PC, Mac)
- At least **2 GB free storage**
- Internet connection (for initial install)

---

## Installation

```bash
# 1. Clone the repository
git clone https://github.com/YOUR_USERNAME/DraconOS
cd DraconOS

# 2. Make installer executable
chmod +x install.sh

# 3. Run the installer
bash install.sh
```

The installer will:
1. Install all required packages via `pkg`
2. Install Python dependencies
3. Set up the Dracon OS file structure at `~/.dracon`
4. Register the `dracon` and `dpm` commands globally
5. Configure VNC with your chosen password
6. Apply the Alpine theme

---

## Usage

```bash
# Start Dracon OS
dracon start

# Stop Dracon OS  
dracon stop

# Restart
dracon restart

# Show status
dracon status

# Edit config
dracon config

# Watch boot log
dracon log

# Update to latest version
dracon update
```

### Connecting via RealVNC Viewer

1. Open **RealVNC Viewer** on your device
2. Add a new connection → Address: `localhost:5901`
3. Enter your VNC password
4. ✅ You're in Dracon OS!

> **Remote device?** Use your phone's local IP instead of `localhost`  
> Find it with: `ip route get 1 | awk '{print $7}'`

---

## Package Manager (dpm)

```bash
# Install packages
dpm install browser git python node

# Remove packages
dpm remove browser

# Search packages
dpm search music

# List installed
dpm list

# Update package list
dpm update
```

### Available Packages

| Package | Description |
|---------|-------------|
| `browser` | Web browser (Firefox) |
| `editor` | Code editor (VSCode Server) |
| `files` | File manager (Thunar) |
| `monitor` | System monitor (htop) |
| `music` | Media player (VLC) |
| `git` | Git version control |
| `python` | Python 3 runtime |
| `node` | Node.js runtime |
| `vim` | Terminal text editor |
| `tmux` | Terminal multiplexer |
| `neofetch` | System info display |

---

## Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `Super` | Open app launcher (Rofi) |
| `Ctrl+Alt+T` | Open terminal (xterm) |
| `Super+←/→` | Snap window left/right |
| `Super+↑` | Maximize window |
| `Super+↓` | Minimize window |
| `Ctrl+Alt+←/→` | Switch workspace |
| `Alt+F4` | Close window |
| `Print` | Screenshot |
| `Right-click desktop` | Desktop menu |

---

## Configuration

Edit `~/.dracon/config/dracon.conf` or run `dracon config`:

```bash
# Resolution
DRACON_RESOLUTION="1280x720"   # Change to 1920x1080 for HD

# Theme
DRACON_THEME="alpine"

# VNC Port
DRACON_VNC_PORT="5901"

# Colors
DRACON_COLOR_ACCENT="#f84c4c"  # Red accent — change to your preference
```

---

## Project Structure

```
DraconOS/
├── install.sh              # Main installer
├── core/
│   └── boot.sh             # Boot controller (dracon command)
├── desktop/
│   ├── desktop.sh          # Desktop environment launcher
│   └── wallpaper.py        # Alpine wallpaper generator (Python)
├── vnc/
│   └── start-vnc.sh        # VNC management
├── pkgman/
│   └── dpm.sh              # Dracon Package Manager
├── apps/
│   └── monitor.py          # System monitor (Python + curses)
├── themes/
│   └── alpine/
│       ├── tint2rc         # Panel theme
│       ├── rofi.rasi       # App launcher theme
│       └── wallpaper.png   # (generated on first boot)
├── config/
│   ├── dracon.conf         # Main config
│   └── openbox.xml         # Window manager config
└── tools/
    └── update.sh           # Auto-updater
```

---

## Troubleshooting

**Black screen in VNC?**
```bash
dracon stop && dracon start
```

**VNC port already in use?**
```bash
vncserver -kill :1
dracon start
```

**Slow performance?**
Edit `~/.dracon/config/dracon.conf` → set `DRACON_DEPTH="16"`

**Reset VNC password?**
```bash
vncpasswd
dracon restart
```

---

## License

MIT License — see [LICENSE](LICENSE) for details.

---

<div align="center">

Built with ❤️ — **Dracon OS**

</div>
