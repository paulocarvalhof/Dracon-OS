#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
#   Dracon OS — Installer
#   Version: 1.0.0
#   Author: Your Name
#   License: MIT
# ============================================================

DRACON_VERSION="1.0.0"
DRACON_DIR="$HOME/.dracon"
DRACON_SRC="$(cd "$(dirname "$0")" && pwd)"

# ─── Colors ────────────────────────────────────────────────
R='\033[0;31m'
G='\033[0;32m'
B='\033[0;34m'
C='\033[0;36m'
Y='\033[1;33m'
W='\033[1;37m'
DIM='\033[2m'
NC='\033[0m'

# ─── Banner ─────────────────────────────────────────────────
banner() {
  clear
  echo -e "${R}"
  echo '  ██████╗ ██████╗  █████╗  ██████╗ ██████╗ ███╗   ██╗'
  echo '  ██╔══██╗██╔══██╗██╔══██╗██╔════╝██╔═══██╗████╗  ██║'
  echo '  ██║  ██║██████╔╝███████║██║     ██║   ██║██╔██╗ ██║'
  echo '  ██║  ██║██╔══██╗██╔══██║██║     ██║   ██║██║╚██╗██║'
  echo '  ██████╔╝██║  ██║██║  ██║╚██████╗╚██████╔╝██║ ╚████║'
  echo '  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝ ╚═════╝ ╚═╝  ╚═══╝'
  echo -e "${DIM}${W}                        O  S  ${R}v${DRACON_VERSION}${NC}"
  echo ""
  echo -e "${DIM}  Alpine-inspired desktop OS for Termux + VNC${NC}"
  echo -e "${DIM}  ──────────────────────────────────────────${NC}"
  echo ""
}

# ─── Logging ────────────────────────────────────────────────
log_info()  { echo -e "  ${C}[INFO]${NC}  $1"; }
log_ok()    { echo -e "  ${G}[ OK ]${NC}  $1"; }
log_warn()  { echo -e "  ${Y}[WARN]${NC}  $1"; }
log_err()   { echo -e "  ${R}[FAIL]${NC}  $1"; }
log_step()  { echo -e "\n  ${W}══ $1 ══${NC}"; }

# ─── Check root environment ─────────────────────────────────
check_env() {
  log_step "Checking Environment"

  if [ ! -d "/data/data/com.termux" ]; then
    log_warn "Not running inside Termux — continuing anyway"
  else
    log_ok "Termux environment detected"
  fi

  if ! command -v pkg &>/dev/null && ! command -v apt &>/dev/null; then
    log_err "No package manager found (pkg/apt)"
    exit 1
  fi
  log_ok "Package manager found"
}

# ─── Install system dependencies ────────────────────────────
install_deps() {
  log_step "Installing Dependencies"

  PKGS=(
    x11-repo
    tigervnc
    openbox
    xterm
    python
    python-pip
    feh
    tint2
    rofi
    wget
    curl
    git
    unzip
    jq
  )

  pkg update -y &>/dev/null
  log_ok "Repositories updated"

  for pkg in "${PKGS[@]}"; do
    echo -ne "  ${DIM}Installing ${pkg}...${NC}\r"
    pkg install -y "$pkg" &>/dev/null 2>&1
    echo -e "  ${G}✓${NC} $pkg                    "
  done

  pip install pillow psutil pynput --quiet 2>/dev/null
  log_ok "Python packages installed"
}

# ─── Install Dracon OS files ─────────────────────────────────
install_dracon() {
  log_step "Installing Dracon OS"

  mkdir -p "$DRACON_DIR"/{bin,config,themes,logs,packages,cache,wallpapers,apps}

  # Copy all source files
  cp -r "$DRACON_SRC/core/"*      "$DRACON_DIR/bin/"      2>/dev/null
  cp -r "$DRACON_SRC/desktop/"*   "$DRACON_DIR/bin/"      2>/dev/null
  cp -r "$DRACON_SRC/vnc/"*       "$DRACON_DIR/bin/"      2>/dev/null
  cp -r "$DRACON_SRC/apps/"*      "$DRACON_DIR/apps/"     2>/dev/null
  cp -r "$DRACON_SRC/pkgman/"*    "$DRACON_DIR/bin/"      2>/dev/null
  cp -r "$DRACON_SRC/themes/"*    "$DRACON_DIR/themes/"   2>/dev/null
  cp -r "$DRACON_SRC/config/"*    "$DRACON_DIR/config/"   2>/dev/null

  chmod +x "$DRACON_DIR/bin/"*.sh 2>/dev/null
  chmod +x "$DRACON_DIR/bin/"*.py 2>/dev/null

  log_ok "Files installed to $DRACON_DIR"

  # Create global command
  ln -sf "$DRACON_DIR/bin/boot.sh"   "$PREFIX/bin/dracon"     2>/dev/null ||
  ln -sf "$DRACON_DIR/bin/boot.sh"   "/usr/local/bin/dracon"  2>/dev/null
  chmod +x "$PREFIX/bin/dracon" 2>/dev/null

  log_ok "Command 'dracon' registered"

  # Create dpm command (package manager)
  ln -sf "$DRACON_DIR/bin/dpm.sh" "$PREFIX/bin/dpm" 2>/dev/null ||
  ln -sf "$DRACON_DIR/bin/dpm.sh" "/usr/local/bin/dpm" 2>/dev/null
  chmod +x "$PREFIX/bin/dpm" 2>/dev/null

  log_ok "Package manager 'dpm' registered"
}

# ─── Configure VNC ──────────────────────────────────────────
configure_vnc() {
  log_step "Configuring VNC"

  mkdir -p "$HOME/.vnc"

  # VNC startup script
  cat > "$HOME/.vnc/xstartup" << 'XSTARTUP'
#!/bin/bash
export DRACON_HOME="$HOME/.dracon"
export DISPLAY=:1
export XDG_RUNTIME_DIR="$HOME/.dracon/runtime"
mkdir -p "$XDG_RUNTIME_DIR"

# Launch Dracon Desktop
bash "$DRACON_HOME/bin/desktop.sh" &

# Launch panel
bash "$DRACON_HOME/bin/panel.sh" &

# Launch Openbox (window manager)
exec openbox --config-file "$DRACON_HOME/config/openbox.xml"
XSTARTUP

  chmod +x "$HOME/.vnc/xstartup"
  log_ok "VNC xstartup configured"

  # Set VNC password
  echo ""
  log_info "Set your VNC password (min 6 characters):"
  vncpasswd
  log_ok "VNC password saved"
}

# ─── Apply Alpine Theme ──────────────────────────────────────
apply_theme() {
  log_step "Applying Alpine Theme"

  cp -r "$DRACON_SRC/themes/alpine/"* "$DRACON_DIR/themes/alpine/" 2>/dev/null
  cp "$DRACON_SRC/config/dracon.conf" "$DRACON_DIR/config/" 2>/dev/null
  cp "$DRACON_SRC/config/openbox.xml" "$DRACON_DIR/config/" 2>/dev/null

  log_ok "Alpine theme applied"
}

# ─── Final message ───────────────────────────────────────────
finish() {
  log_step "Installation Complete"
  echo ""
  echo -e "  ${G}╔════════════════════════════════════════╗${NC}"
  echo -e "  ${G}║${NC}  ${W}Dracon OS installed successfully!${NC}    ${G}║${NC}"
  echo -e "  ${G}╠════════════════════════════════════════╣${NC}"
  echo -e "  ${G}║${NC}                                        ${G}║${NC}"
  echo -e "  ${G}║${NC}  ${C}Start OS:${NC}  dracon start              ${G}║${NC}"
  echo -e "  ${G}║${NC}  ${C}Stop OS:${NC}   dracon stop               ${G}║${NC}"
  echo -e "  ${G}║${NC}  ${C}Packages:${NC}  dpm install <pkg>         ${G}║${NC}"
  echo -e "  ${G}║${NC}  ${C}VNC Port:${NC}  5901                      ${G}║${NC}"
  echo -e "  ${G}║${NC}                                        ${G}║${NC}"
  echo -e "  ${G}╚════════════════════════════════════════╝${NC}"
  echo ""
  echo -e "  ${DIM}Connect via RealVNC Viewer → localhost:5901${NC}"
  echo ""
}

# ─── Entry Point ─────────────────────────────────────────────
main() {
  banner
  check_env
  install_deps
  install_dracon
  configure_vnc
  apply_theme
  finish
}

main "$@"
