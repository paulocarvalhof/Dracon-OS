#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
#   Dracon OS — Boot & Main Controller
#   core/boot.sh
# ============================================================

DRACON_HOME="$HOME/.dracon"
DRACON_VERSION="1.0.0"
VNC_DISPLAY=":1"
VNC_PORT="5901"
LOG="$DRACON_HOME/logs/dracon.log"

# ─── Colors ────────────────────────────────────────────────
R='\033[0;31m'
G='\033[0;32m'
C='\033[0;36m'
Y='\033[1;33m'
W='\033[1;37m'
DIM='\033[2m'
NC='\033[0m'

mkdir -p "$DRACON_HOME/logs"

log() { echo "[$(date '+%H:%M:%S')] $1" >> "$LOG"; }

# ─── Boot Banner ────────────────────────────────────────────
boot_banner() {
  clear
  echo -e "${R}"
  echo '  ██████╗ ██████╗  █████╗  ██████╗ ██████╗ ███╗   ██╗'
  echo '  ██╔══██╗██╔══██╗██╔══██╗██╔════╝██╔═══██╗████╗  ██║'
  echo '  ██║  ██║██████╔╝███████║██║     ██║   ██║██╔██╗ ██║'
  echo '  ██║  ██║██╔══██╗██╔══██║██║     ██║   ██║██║╚██╗██║'
  echo '  ██████╔╝██║  ██║██║  ██║╚██████╗╚██████╔╝██║ ╚████║'
  echo '  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝ ╚═════╝ ╚═╝  ╚═══╝'
  echo -e "${DIM}${W}                     O  S  ${R}v${DRACON_VERSION}${NC}"
  echo ""
}

# ─── Animated Boot Sequence ─────────────────────────────────
boot_sequence() {
  STEPS=(
    "Initializing kernel modules"
    "Mounting filesystems"
    "Starting device manager"
    "Loading display server (X11)"
    "Configuring VNC server"
    "Starting window manager"
    "Loading desktop environment"
    "Applying Alpine theme"
    "Starting system services"
    "Boot complete"
  )

  echo -e "  ${DIM}──────────────────────────────────────────────${NC}"
  for step in "${STEPS[@]}"; do
    echo -ne "  ${DIM}[  ....  ]${NC} ${step}...\r"
    sleep 0.3
    echo -e "  ${G}[  OK    ]${NC} ${step}   "
    log "BOOT: $step"
  done
  echo -e "  ${DIM}──────────────────────────────────────────────${NC}"
  echo ""
}

# ─── Start Dracon OS ────────────────────────────────────────
cmd_start() {
  boot_banner
  boot_sequence

  # Kill any old VNC sessions
  vncserver -kill "$VNC_DISPLAY" &>/dev/null
  pkill -f "Xtightvnc\|Xvnc\|tigervnc" 2>/dev/null
  sleep 1

  # Load config
  source "$DRACON_HOME/config/dracon.conf" 2>/dev/null

  RESOLUTION="${DRACON_RESOLUTION:-1280x720}"
  DEPTH="${DRACON_DEPTH:-24}"

  echo -e "  ${C}Starting VNC Server...${NC}"
  log "Starting VNC :1 @ ${RESOLUTION}"

  vncserver "$VNC_DISPLAY" \
    -geometry "$RESOLUTION" \
    -depth "$DEPTH" \
    -localhost no \
    -SecurityTypes VncAuth \
    >> "$LOG" 2>&1

  if [ $? -eq 0 ]; then
    echo -e "  ${G}✓ Dracon OS is running!${NC}"
    echo ""
    echo -e "  ${W}┌─────────────────────────────────────┐${NC}"
    echo -e "  ${W}│${NC}  ${C}VNC Port:${NC}    ${Y}${VNC_PORT}${NC}                  ${W}│${NC}"
    echo -e "  ${W}│${NC}  ${C}Resolution:${NC}  ${Y}${RESOLUTION}${NC}            ${W}│${NC}"
    echo -e "  ${W}│${NC}  ${C}Connect:${NC}     ${Y}localhost:${VNC_PORT}${NC}          ${W}│${NC}"
    echo -e "  ${W}│${NC}  ${C}Log:${NC}         ${DIM}~/.dracon/logs/dracon.log${NC} ${W}│${NC}"
    echo -e "  ${W}└─────────────────────────────────────┘${NC}"
    echo ""
    log "Dracon OS started successfully"
  else
    echo -e "  ${R}✗ Failed to start VNC server${NC}"
    echo -e "  ${DIM}Check: $LOG${NC}"
    log "ERROR: VNC server failed to start"
    exit 1
  fi
}

# ─── Stop Dracon OS ─────────────────────────────────────────
cmd_stop() {
  boot_banner
  echo -e "  ${Y}Shutting down Dracon OS...${NC}"
  log "Shutdown requested"

  vncserver -kill "$VNC_DISPLAY" &>/dev/null
  pkill -f "openbox|tint2|feh|dracon-panel" 2>/dev/null

  echo -e "  ${G}✓ Dracon OS stopped${NC}"
  log "Dracon OS stopped"
}

# ─── Restart ────────────────────────────────────────────────
cmd_restart() {
  cmd_stop
  sleep 2
  cmd_start
}

# ─── Status ─────────────────────────────────────────────────
cmd_status() {
  boot_banner
  echo -e "  ${W}System Status${NC}"
  echo -e "  ${DIM}──────────────────────────────${NC}"

  if pgrep -f "Xvnc\|Xtightvnc" &>/dev/null; then
    echo -e "  ${G}●${NC} VNC Server    ${G}running${NC} (port ${VNC_PORT})"
  else
    echo -e "  ${R}●${NC} VNC Server    ${R}stopped${NC}"
  fi

  if pgrep openbox &>/dev/null; then
    echo -e "  ${G}●${NC} Openbox WM    ${G}running${NC}"
  else
    echo -e "  ${Y}●${NC} Openbox WM    ${Y}not running${NC}"
  fi

  if pgrep tint2 &>/dev/null; then
    echo -e "  ${G}●${NC} Tint2 Panel   ${G}running${NC}"
  else
    echo -e "  ${Y}●${NC} Tint2 Panel   ${Y}not running${NC}"
  fi

  echo ""
  echo -e "  ${DIM}Version: Dracon OS v${DRACON_VERSION}${NC}"
  echo -e "  ${DIM}Log: $LOG${NC}"
  echo ""
}

# ─── Help ────────────────────────────────────────────────────
cmd_help() {
  boot_banner
  echo -e "  ${W}Usage:${NC} dracon <command>"
  echo ""
  echo -e "  ${C}Commands:${NC}"
  echo -e "    ${G}start${NC}      Start Dracon OS (VNC)"
  echo -e "    ${G}stop${NC}       Stop Dracon OS"
  echo -e "    ${G}restart${NC}    Restart Dracon OS"
  echo -e "    ${G}status${NC}     Show system status"
  echo -e "    ${G}config${NC}     Open configuration editor"
  echo -e "    ${G}log${NC}        Show boot log"
  echo -e "    ${G}update${NC}     Update Dracon OS"
  echo -e "    ${G}help${NC}       Show this help"
  echo ""
  echo -e "  ${C}Package Manager:${NC}"
  echo -e "    ${G}dpm install${NC} <pkg>    Install a package"
  echo -e "    ${G}dpm remove${NC}  <pkg>    Remove a package"
  echo -e "    ${G}dpm list${NC}             List installed packages"
  echo -e "    ${G}dpm search${NC}  <query>  Search packages"
  echo -e "    ${G}dpm update${NC}           Update package list"
  echo ""
}

# ─── Config Editor ──────────────────────────────────────────
cmd_config() {
  "${EDITOR:-nano}" "$DRACON_HOME/config/dracon.conf"
}

# ─── Log Viewer ─────────────────────────────────────────────
cmd_log() {
  tail -f "$LOG"
}

# ─── Updater ────────────────────────────────────────────────
cmd_update() {
  boot_banner
  echo -e "  ${C}Updating Dracon OS...${NC}"
  bash "$DRACON_HOME/../tools/update.sh"
}

# ─── Dispatcher ─────────────────────────────────────────────
case "${1:-help}" in
  start)   cmd_start   ;;
  stop)    cmd_stop    ;;
  restart) cmd_restart ;;
  status)  cmd_status  ;;
  config)  cmd_config  ;;
  log)     cmd_log     ;;
  update)  cmd_update  ;;
  help|--help|-h) cmd_help ;;
  *)
    echo -e "  ${R}Unknown command: $1${NC}"
    cmd_help
    exit 1
    ;;
esac
