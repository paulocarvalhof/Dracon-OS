#!/usr/bin/env python3
# ============================================================
#   Dracon OS v1.1.0 — Settings App
#   apps/settings/settings.py
# ============================================================

import curses, os, json, subprocess

CONF = os.path.expanduser("~/.dracon/config/dracon.conf")
THEMES_DIR = os.path.expanduser("~/.dracon/themes")

SECTIONS = ["🖥️  Display", "🎨 Theme", "🔊 Sound", "🖱️  Desktop", "🔒 VNC", "ℹ️  About"]

DEFAULTS = {
    "DRACON_RESOLUTION": "1280x720",
    "DRACON_DEPTH": "24",
    "DRACON_THEME": "alpine",
    "DRACON_VNC_PORT": "5901",
    "DRACON_PANEL_POSITION": "bottom",
    "DRACON_COLOR_ACCENT": "#f84c4c",
    "DRACON_FONT_UI": "DejaVu Sans 10",
}

RESOLUTIONS = ["1280x720", "1366x768", "1440x900", "1600x900", "1920x1080", "2560x1440"]
THEMES_LIST = ["alpine", "dark", "ocean", "forest"]
DEPTHS      = ["16", "24", "32"]
POSITIONS   = ["bottom", "top"]

def load_conf():
    cfg = dict(DEFAULTS)
    try:
        for line in open(CONF):
            line = line.strip()
            if "=" in line and not line.startswith("#"):
                k, _, v = line.partition("=")
                cfg[k.strip()] = v.strip().strip('"')
    except:
        pass
    return cfg

def save_conf(cfg):
    try:
        lines = []
        try:
            lines = open(CONF).readlines()
        except:
            pass

        new_lines = []
        written = set()
        for line in lines:
            stripped = line.strip()
            if "=" in stripped and not stripped.startswith("#"):
                k = stripped.split("=")[0].strip()
                if k in cfg:
                    new_lines.append(f'{k}="{cfg[k]}"\n')
                    written.add(k)
                else:
                    new_lines.append(line)
            else:
                new_lines.append(line)

        for k, v in cfg.items():
            if k not in written:
                new_lines.append(f'{k}="{v}"\n')

        os.makedirs(os.path.dirname(CONF), exist_ok=True)
        open(CONF, "w").writelines(new_lines)
    except Exception as e:
        pass

def apply_theme(theme, stdscr, h, w):
    wp_out = os.path.expanduser(f"~/.dracon/themes/{theme}/wallpaper.png")
    wp_script = os.path.expanduser("~/.dracon/bin/wallpaper.py")
    stdscr.addstr(h-2, 2, f" Generating {theme} wallpaper... ", 
                  curses.color_pair(3) | curses.A_BOLD)
    stdscr.refresh()
    subprocess.Popen(["python3", wp_script, wp_out, theme],
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

def draw_settings(stdscr):
    curses.start_color()
    curses.init_pair(1, curses.COLOR_RED,    curses.COLOR_BLACK)
    curses.init_pair(2, curses.COLOR_GREEN,  curses.COLOR_BLACK)
    curses.init_pair(3, curses.COLOR_YELLOW, curses.COLOR_BLACK)
    curses.init_pair(4, curses.COLOR_CYAN,   curses.COLOR_BLACK)
    curses.init_pair(5, curses.COLOR_WHITE,  curses.COLOR_BLACK)
    curses.init_pair(6, curses.COLOR_BLACK,  curses.COLOR_RED)
    curses.curs_set(0)
    stdscr.keypad(True)

    ACC = curses.color_pair(1) | curses.A_BOLD
    GRN = curses.color_pair(2)
    YEL = curses.color_pair(3) | curses.A_BOLD
    CYN = curses.color_pair(4)
    NRM = curses.color_pair(5)
    HDR = curses.color_pair(6) | curses.A_BOLD
    DIM = curses.color_pair(5) | curses.A_DIM

    section  = 0
    cfg      = load_conf()
    sel_item = 0
    saved_msg = ""
    saved_timer = 0

    # Per-section items: (label, config_key, options_list or None)
    ITEMS = {
        0: [  # Display
            ("Resolution",    "DRACON_RESOLUTION", RESOLUTIONS),
            ("Color Depth",   "DRACON_DEPTH",       DEPTHS),
        ],
        1: [  # Theme
            ("Theme",         "DRACON_THEME",       THEMES_LIST),
            ("Accent Color",  "DRACON_COLOR_ACCENT", None),
            ("Font",          "DRACON_FONT_UI",      None),
        ],
        2: [  # Sound
            ("Volume",        None,                  None),
        ],
        3: [  # Desktop
            ("Panel Position","DRACON_PANEL_POSITION", POSITIONS),
        ],
        4: [  # VNC
            ("VNC Port",      "DRACON_VNC_PORT",    None),
        ],
        5: [  # About
        ],
    }

    import time

    while True:
        h, w = stdscr.getmaxyx()
        stdscr.erase()

        # Header
        hdr = "  ⚙️  DRACON OS — SETTINGS  "
        pad = " " * max(0, (w - len(hdr)) // 2)
        stdscr.addstr(0, 0, (pad + hdr + pad)[:w], HDR)

        # Sidebar
        side_w = 20
        for i, sec in enumerate(SECTIONS):
            row = 2 + i * 2
            if row >= h - 3: break
            if i == section:
                stdscr.addstr(row, 1, f"▶ {sec}"[:side_w-1], YEL)
            else:
                stdscr.addstr(row, 1, f"  {sec}"[:side_w-1], DIM)

        # Divider
        for y in range(1, h-1):
            try: stdscr.addstr(y, side_w, "│", DIM)
            except: pass

        # Content panel
        cx = side_w + 2
        cw = w - cx - 2

        if section == 5:  # About
            stdscr.addstr(2,  cx, "Dracon OS", ACC)
            stdscr.addstr(3,  cx, "Version: 1.1.0", CYN)
            stdscr.addstr(5,  cx, "Alpine-inspired desktop OS", NRM)
            stdscr.addstr(6,  cx, "for Termux + VNC", NRM)
            stdscr.addstr(8,  cx, "Built with Bash + Python", DIM)
            stdscr.addstr(9,  cx, "Theme: Openbox + Tint2 + Rofi", DIM)
            stdscr.addstr(11, cx, "github.com/paulocarvalhof/Dracon-OS", DIM)
        else:
            items = ITEMS.get(section, [])
            for i, (label, key, opts) in enumerate(items):
                row = 2 + i * 3
                if row >= h - 4: break
                val = cfg.get(key, "—") if key else "—"

                if i == sel_item:
                    stdscr.addstr(row, cx, f"▶ {label}", YEL)
                    if opts:
                        # Show options inline
                        opt_x = cx + len(label) + 4
                        for j, opt in enumerate(opts):
                            if opt == val:
                                try: stdscr.addstr(row, opt_x, f"[{opt}]", GRN)
                                except: pass
                                opt_x += len(opt) + 3
                            else:
                                try: stdscr.addstr(row, opt_x, opt, DIM)
                                except: pass
                                opt_x += len(opt) + 2
                    else:
                        try:
                            stdscr.addstr(row, cx + len(label) + 4,
                                          f"→ {val}", CYN)
                        except: pass
                else:
                    stdscr.addstr(row, cx, f"  {label}", NRM)
                    try:
                        stdscr.addstr(row, cx + len(label) + 4, val, DIM)
                    except: pass

        # Saved message
        if saved_msg and time.time() < saved_timer:
            try: stdscr.addstr(h-2, w//2-len(saved_msg)//2, saved_msg, GRN)
            except: pass

        # Footer
        stdscr.addstr(h-2, 0, "─" * w, DIM)
        stdscr.addstr(h-1, 2,
            " Tab/↑↓:Navigate  ←→:Change  S:Save  A:Apply Theme  Q:Quit ", DIM)

        stdscr.refresh()

        key = stdscr.getch()
        items = ITEMS.get(section, [])

        if key in (ord('q'), ord('Q'), 27):
            break
        elif key == 9 or key == curses.KEY_RIGHT and not items:  # Tab
            section = (section + 1) % len(SECTIONS)
            sel_item = 0
        elif key == curses.KEY_DOWN:
            if items:
                sel_item = (sel_item + 1) % len(items)
        elif key == curses.KEY_UP:
            if items:
                sel_item = (sel_item - 1) % len(items)
        elif key == curses.KEY_BTAB:
            section = (section - 1) % len(SECTIONS)
            sel_item = 0
        elif key == curses.KEY_LEFT or key == curses.KEY_RIGHT:
            if items and sel_item < len(items):
                label, ckey, opts = items[sel_item]
                if opts and ckey:
                    cur_val = cfg.get(ckey, opts[0])
                    idx = opts.index(cur_val) if cur_val in opts else 0
                    if key == curses.KEY_RIGHT:
                        idx = (idx + 1) % len(opts)
                    else:
                        idx = (idx - 1) % len(opts)
                    cfg[ckey] = opts[idx]
        elif key in (ord('s'), ord('S')):
            save_conf(cfg)
            saved_msg = " ✓ Settings saved! Restart to apply. "
            saved_timer = time.time() + 3
        elif key in (ord('a'), ord('A')):
            theme = cfg.get("DRACON_THEME", "alpine")
            apply_theme(theme, stdscr, h, w)
            saved_msg = f" ✓ Applying {theme} theme... "
            saved_timer = time.time() + 3

def main():
    try:
        curses.wrapper(draw_settings)
    except KeyboardInterrupt:
        pass

if __name__ == "__main__":
    main()
