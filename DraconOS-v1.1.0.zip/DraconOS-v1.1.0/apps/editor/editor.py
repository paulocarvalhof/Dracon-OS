#!/usr/bin/env python3
# ============================================================
#   Dracon OS v1.1.0 — Text Editor (DraconEdit)
#   apps/editor/editor.py
# ============================================================

import curses, os, sys

def draw_editor(stdscr, filepath=None):
    curses.start_color()
    curses.init_pair(1, curses.COLOR_RED,    curses.COLOR_BLACK)
    curses.init_pair(2, curses.COLOR_WHITE,  curses.COLOR_BLACK)
    curses.init_pair(3, curses.COLOR_BLACK,  curses.COLOR_RED)
    curses.init_pair(4, curses.COLOR_CYAN,   curses.COLOR_BLACK)
    curses.init_pair(5, curses.COLOR_YELLOW, curses.COLOR_BLACK)
    curses.init_pair(6, curses.COLOR_GREEN,  curses.COLOR_BLACK)
    curses.init_pair(7, curses.COLOR_BLACK,  curses.COLOR_WHITE)
    curses.curs_set(1)

    ACC  = curses.color_pair(1) | curses.A_BOLD
    NRM  = curses.color_pair(2)
    HDR  = curses.color_pair(3) | curses.A_BOLD
    CYN  = curses.color_pair(4)
    YEL  = curses.color_pair(5)
    GRN  = curses.color_pair(6)
    DIM  = curses.color_pair(2) | curses.A_DIM
    BWHT = curses.color_pair(7)

    lines = [""]
    modified = False
    cur_y = 0  # cursor row in lines
    cur_x = 0  # cursor col
    scroll_y = 0
    filename = filepath or "untitled.txt"
    status_msg = ""

    if filepath and os.path.exists(filepath):
        try:
            with open(filepath) as f:
                content = f.read()
            lines = content.split("\n")
            if not lines:
                lines = [""]
        except Exception as e:
            status_msg = f"Error opening: {e}"

    # Keywords for basic syntax highlighting
    KEYWORDS = {"def","class","import","from","return","if","else","elif",
                "for","while","in","not","and","or","True","False","None",
                "try","except","finally","with","as","pass","break","continue"}

    def render_line(stdscr, row, line, x_off, width, attr):
        """Render with basic keyword highlight."""
        display = line[x_off:x_off+width]
        words = display.split()
        stdscr.addstr(row, 0, " " * width, NRM)
        col = 0
        remainder = display
        while remainder:
            # Try to find next keyword
            best_start = len(remainder)
            best_word = None
            for kw in KEYWORDS:
                idx = remainder.find(kw)
                if idx != -1 and idx < best_start:
                    # Check word boundary
                    end = idx + len(kw)
                    if (idx == 0 or not remainder[idx-1].isalnum()) and \
                       (end >= len(remainder) or not remainder[end].isalnum()):
                        best_start = idx
                        best_word = kw
            if best_word and best_start >= 0:
                # Print up to keyword
                if best_start > 0:
                    try: stdscr.addstr(row, col, remainder[:best_start], attr)
                    except: pass
                    col += best_start
                # Print keyword highlighted
                try: stdscr.addstr(row, col, best_word, YEL | curses.A_BOLD)
                except: pass
                col += len(best_word)
                remainder = remainder[best_start + len(best_word):]
            else:
                try: stdscr.addstr(row, col, remainder, attr)
                except: pass
                break

    while True:
        h, w = stdscr.getmaxyx()
        edit_h = h - 3  # lines area height
        line_no_w = 5

        stdscr.erase()

        # Header
        title = f"  ✏️  DraconEdit — {os.path.basename(filename)}{'*' if modified else ''}  "
        pad = " " * max(0, (w - len(title)) // 2)
        try: stdscr.addstr(0, 0, (pad + title + pad)[:w], HDR)
        except: pass

        # Adjust scroll
        if cur_y < scroll_y:
            scroll_y = cur_y
        if cur_y >= scroll_y + edit_h:
            scroll_y = cur_y - edit_h + 1

        # Line display
        for screen_row in range(edit_h):
            line_idx = screen_row + scroll_y
            row = screen_row + 1

            # Line number
            try:
                if line_idx < len(lines):
                    ln = f"{line_idx+1:>{line_no_w-1}} "
                    stdscr.addstr(row, 0, ln, DIM)
                else:
                    stdscr.addstr(row, 0, "~" + " "*(line_no_w-1), DIM)
            except: pass

            # Line content
            if line_idx < len(lines):
                line = lines[line_idx]
                is_cur = (line_idx == cur_y)
                attr = CYN if is_cur else NRM
                content_w = w - line_no_w - 1
                try:
                    render_line(stdscr, row, line, 0, content_w, attr)
                except: pass

        # Status bar
        pos = f" Ln {cur_y+1}/{len(lines)}  Col {cur_x+1} "
        mode = " INSERT "
        info = f" {filename} "
        try:
            stdscr.addstr(h-2, 0, " " * w, BWHT)
            stdscr.addstr(h-2, 0, mode, HDR)
            stdscr.addstr(h-2, len(mode)+1, info[:w//2], BWHT)
            stdscr.addstr(h-2, w-len(pos)-1, pos, BWHT)
        except: pass

        # Status message / shortcuts
        if status_msg:
            msg = status_msg[:w-2]
            try: stdscr.addstr(h-1, 2, msg, GRN)
            except: pass
        else:
            try:
                stdscr.addstr(h-1, 2,
                    "^S:Save  ^O:Open  ^N:New  ^Q:Quit  ^Z:Undo", DIM)
            except: pass

        # Cursor
        screen_cur_y = cur_y - scroll_y + 1
        screen_cur_x = min(cur_x, w - line_no_w - 2) + line_no_w
        try:
            stdscr.move(screen_cur_y, screen_cur_x)
        except: pass

        stdscr.refresh()

        key = stdscr.getch()

        # Navigation
        if key == curses.KEY_UP:
            if cur_y > 0:
                cur_y -= 1
                cur_x = min(cur_x, len(lines[cur_y]))
        elif key == curses.KEY_DOWN:
            if cur_y < len(lines) - 1:
                cur_y += 1
                cur_x = min(cur_x, len(lines[cur_y]))
        elif key == curses.KEY_LEFT:
            if cur_x > 0:
                cur_x -= 1
            elif cur_y > 0:
                cur_y -= 1
                cur_x = len(lines[cur_y])
        elif key == curses.KEY_RIGHT:
            if cur_x < len(lines[cur_y]):
                cur_x += 1
            elif cur_y < len(lines) - 1:
                cur_y += 1
                cur_x = 0
        elif key == curses.KEY_HOME:
            cur_x = 0
        elif key == curses.KEY_END:
            cur_x = len(lines[cur_y])
        elif key == curses.KEY_PPAGE:
            cur_y = max(0, cur_y - edit_h)
            cur_x = min(cur_x, len(lines[cur_y]))
        elif key == curses.KEY_NPAGE:
            cur_y = min(len(lines)-1, cur_y + edit_h)
            cur_x = min(cur_x, len(lines[cur_y]))

        # Ctrl+Q — Quit
        elif key == 17:  # Ctrl+Q
            if modified:
                status_msg = "Unsaved changes! Press Ctrl+Q again to quit."
                modified = False  # second press exits
            else:
                break

        # Ctrl+S — Save
        elif key == 19:  # Ctrl+S
            try:
                with open(filename, "w") as f:
                    f.write("\n".join(lines))
                modified = False
                status_msg = f"✓ Saved: {filename}"
            except Exception as e:
                status_msg = f"Error saving: {e}"

        # Ctrl+N — New
        elif key == 14:
            lines = [""]
            cur_y = cur_x = scroll_y = 0
            filename = "untitled.txt"
            modified = False
            status_msg = "New file"

        # Enter
        elif key in (10, 13):
            current = lines[cur_y]
            lines[cur_y] = current[:cur_x]
            lines.insert(cur_y + 1, current[cur_x:])
            cur_y += 1
            cur_x = 0
            modified = True
            status_msg = ""

        # Backspace
        elif key in (curses.KEY_BACKSPACE, 127, 8):
            if cur_x > 0:
                lines[cur_y] = lines[cur_y][:cur_x-1] + lines[cur_y][cur_x:]
                cur_x -= 1
                modified = True
            elif cur_y > 0:
                prev_len = len(lines[cur_y - 1])
                lines[cur_y - 1] += lines[cur_y]
                lines.pop(cur_y)
                cur_y -= 1
                cur_x = prev_len
                modified = True
            status_msg = ""

        # Delete
        elif key == curses.KEY_DC:
            if cur_x < len(lines[cur_y]):
                lines[cur_y] = lines[cur_y][:cur_x] + lines[cur_y][cur_x+1:]
                modified = True
            elif cur_y < len(lines) - 1:
                lines[cur_y] += lines.pop(cur_y + 1)
                modified = True
            status_msg = ""

        # Tab
        elif key == 9:
            lines[cur_y] = lines[cur_y][:cur_x] + "    " + lines[cur_y][cur_x:]
            cur_x += 4
            modified = True
            status_msg = ""

        # Printable character
        elif 32 <= key <= 126:
            ch = chr(key)
            lines[cur_y] = lines[cur_y][:cur_x] + ch + lines[cur_y][cur_x:]
            cur_x += 1
            modified = True
            status_msg = ""


def main():
    filepath = sys.argv[1] if len(sys.argv) > 1 else None
    try:
        curses.wrapper(draw_editor, filepath)
    except KeyboardInterrupt:
        pass

if __name__ == "__main__":
    main()
