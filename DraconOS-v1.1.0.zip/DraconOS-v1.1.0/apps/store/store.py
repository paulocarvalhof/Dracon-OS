#!/usr/bin/env python3
# ============================================================
#   Dracon OS v1.1.0 — Dracon Store
#   apps/store/store.py
# ============================================================

import curses, os, json, subprocess, time

STORE_DB = os.path.expanduser("~/.dracon/packages/installed.json")

CATALOG = [
    # name, category, description, pkg, icon
    ("Firefox",       "Browser",     "Full web browser",              "firefox",      "🌐"),
    ("Chromium",      "Browser",     "Chromium browser",              "chromium",     "🔵"),
    ("VSCode Server", "Development", "Code editor in browser",        "code-server",  "💻"),
    ("Vim",           "Development", "Terminal text editor",          "vim",          "📝"),
    ("Neovim",        "Development", "Modern Vim fork",               "neovim",       "📝"),
    ("Git",           "Development", "Version control system",        "git",          "🌿"),
    ("Python",        "Development", "Python 3 runtime",              "python",       "🐍"),
    ("Node.js",       "Development", "JavaScript runtime",            "nodejs",       "💚"),
    ("Thunar",        "Files",       "Graphical file manager",        "thunar",       "📁"),
    ("Midnight Cmd",  "Files",       "Terminal file manager",         "mc",           "📂"),
    ("VLC",           "Media",       "Media player",                  "vlc",          "🎬"),
    ("mpv",           "Media",       "Lightweight video player",      "mpv",          "▶️"),
    ("htop",          "System",      "System process monitor",        "htop",         "📊"),
    ("Neofetch",      "System",      "System info display",           "neofetch",     "🖥️"),
    ("Tmux",          "System",      "Terminal multiplexer",          "tmux",         "⬛"),
    ("Wget",          "Network",     "File downloader",               "wget",         "⬇️"),
    ("Curl",          "Network",     "HTTP client",                   "curl",         "🌀"),
    ("OpenSSH",       "Network",     "SSH client & server",           "openssh",      "🔐"),
    ("Nmap",          "Network",     "Network scanner",               "nmap",         "🔍"),
    ("Scrot",         "Utilities",   "Screenshot tool",               "scrot",        "📷"),
    ("Galculator",    "Utilities",   "Graphical calculator",          "galculator",   "🔢"),
    ("Geany",         "Utilities",   "Lightweight IDE",               "geany",        "✏️"),
    ("Nano",          "Utilities",   "Simple text editor",            "nano",         "📄"),
]

CATEGORIES = ["All", "Browser", "Development", "Files", "Media", "System", "Network", "Utilities"]

def load_installed():
    try:
        db = json.load(open(STORE_DB))
        return set(db.get("packages", {}).keys())
    except:
        return set()

def mark_installed(pkg_name):
    try:
        try:
            db = json.load(open(STORE_DB))
        except:
            db = {"packages": {}}
        db["packages"][pkg_name.lower().replace(" ", "_")] = {
            "version": "latest",
            "installed_at": time.strftime("%Y-%m-%dT%H:%M:%S")
        }
        os.makedirs(os.path.dirname(STORE_DB), exist_ok=True)
        json.dump(db, open(STORE_DB, "w"), indent=2)
    except:
        pass

def install_pkg(pkg, stdscr, h, w):
    stdscr.addstr(h-2, 2, f" Installing {pkg}... (check terminal after exit) ", 
                  curses.color_pair(3) | curses.A_BOLD)
    stdscr.refresh()
    # Run in background
    subprocess.Popen(["pkg", "install", "-y", pkg],
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    time.sleep(1)

def draw_store(stdscr):
    curses.start_color()
    curses.init_pair(1, curses.COLOR_RED,     curses.COLOR_BLACK)   # accent
    curses.init_pair(2, curses.COLOR_GREEN,   curses.COLOR_BLACK)   # installed
    curses.init_pair(3, curses.COLOR_YELLOW,  curses.COLOR_BLACK)   # highlight
    curses.init_pair(4, curses.COLOR_CYAN,    curses.COLOR_BLACK)   # category
    curses.init_pair(5, curses.COLOR_WHITE,   curses.COLOR_BLACK)   # normal
    curses.init_pair(6, curses.COLOR_BLACK,   curses.COLOR_RED)     # header
    curses.init_pair(7, curses.COLOR_BLACK,   curses.COLOR_GREEN)   # btn install
    curses.init_pair(8, curses.COLOR_WHITE,   curses.COLOR_BLACK)   # dim
    curses.curs_set(0)
    stdscr.keypad(True)

    ACC   = curses.color_pair(1) | curses.A_BOLD
    GRN   = curses.color_pair(2)
    YEL   = curses.color_pair(3) | curses.A_BOLD
    CYN   = curses.color_pair(4)
    NRM   = curses.color_pair(5)
    HDR   = curses.color_pair(6) | curses.A_BOLD
    BTN   = curses.color_pair(7) | curses.A_BOLD
    DIM   = curses.color_pair(8) | curses.A_DIM

    cur_cat    = 0
    selected   = 0
    scroll_off = 0

    while True:
        installed = load_installed()
        h, w = stdscr.getmaxyx()
        stdscr.erase()

        # ── Header ──
        hdr = "  🐉 DRACON STORE  "
        pad = " " * ((w - len(hdr)) // 2)
        stdscr.addstr(0, 0, (pad + hdr + pad)[:w], HDR)

        # ── Category tabs ──
        cat_x = 2
        stdscr.addstr(2, 2, "Categories: ", DIM)
        for i, cat in enumerate(CATEGORIES):
            label = f" {cat} "
            if cat_x + len(label) >= w - 2:
                break
            if i == cur_cat:
                stdscr.addstr(2, cat_x + 12, label, YEL)
            else:
                stdscr.addstr(2, cat_x + 12, label, DIM)
            cat_x += len(label) + 1

        stdscr.addstr(3, 0, "─" * w, DIM)

        # ── Filter apps ──
        cat_filter = CATEGORIES[cur_cat]
        filtered = [a for a in CATALOG if cat_filter == "All" or a[1] == cat_filter]

        # ── App list ──
        list_h = h - 8
        if selected >= len(filtered):
            selected = max(0, len(filtered) - 1)
        if selected - scroll_off >= list_h:
            scroll_off = selected - list_h + 1
        if selected < scroll_off:
            scroll_off = selected

        for i, (name, cat, desc, pkg, icon) in enumerate(filtered[scroll_off:scroll_off+list_h]):
            row = 4 + i
            actual_i = i + scroll_off
            is_inst = pkg in installed or name.lower().replace(" ","_") in installed

            line_attr = YEL if actual_i == selected else NRM
            status = f"{GRN}✓ installed{NRM}" if is_inst else f"{DIM}  available{NRM}"

            # Highlight selected row
            if actual_i == selected:
                stdscr.addstr(row, 0, " " * w, curses.color_pair(3) | curses.A_DIM)

            stdscr.addstr(row, 2,  f"{icon} ", NRM)
            stdscr.addstr(row, 6,  f"{name:<18}", line_attr)
            stdscr.addstr(row, 25, f"{cat:<14}", CYN)
            stdscr.addstr(row, 40, f"{desc:<30}"[:30], DIM)
            if is_inst:
                try: stdscr.addstr(row, 72, "✓ installed", GRN)
                except: pass
            else:
                try: stdscr.addstr(row, 72, "  available", DIM)
                except: pass

        # ── Detail panel for selected ──
        if filtered:
            name, cat, desc, pkg, icon = filtered[selected]
            is_inst = pkg in installed
            stdscr.addstr(h-4, 0, "─" * w, DIM)
            stdscr.addstr(h-3, 2, f"{icon} {name}", ACC)
            stdscr.addstr(h-3, 25, f"│ {desc}", DIM)
            if is_inst:
                stdscr.addstr(h-3, w-20, "[INSTALLED]", GRN)
            else:
                stdscr.addstr(h-3, w-20, "[ENTER=Install]", BTN)

        # ── Footer ──
        stdscr.addstr(h-2, 0, "─" * w, DIM)
        stdscr.addstr(h-1, 2,
            " ↑↓:Navigate  ←→:Category  Enter:Install  q:Quit ", DIM)

        stdscr.refresh()

        # ── Input ──
        key = stdscr.getch()
        if key in (ord('q'), ord('Q'), 27):
            break
        elif key == curses.KEY_DOWN and selected < len(filtered) - 1:
            selected += 1
        elif key == curses.KEY_UP and selected > 0:
            selected -= 1
        elif key == curses.KEY_RIGHT:
            cur_cat = (cur_cat + 1) % len(CATEGORIES)
            selected = 0; scroll_off = 0
        elif key == curses.KEY_LEFT:
            cur_cat = (cur_cat - 1) % len(CATEGORIES)
            selected = 0; scroll_off = 0
        elif key in (curses.KEY_ENTER, 10, 13):
            if filtered:
                name, cat, desc, pkg, icon = filtered[selected]
                install_pkg(pkg, stdscr, h, w)
                mark_installed(pkg)


def main():
    try:
        curses.wrapper(draw_store)
    except KeyboardInterrupt:
        pass
    print("\n[store] Dracon Store closed.")

if __name__ == "__main__":
    main()
