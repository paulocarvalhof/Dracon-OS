#!/usr/bin/env python3
# ============================================================
#   Dracon OS v1.1.0 — Calculator
#   apps/calculator/calc.py
# ============================================================

import curses, math

def draw_calc(stdscr):
    curses.start_color()
    curses.init_pair(1, curses.COLOR_RED,    curses.COLOR_BLACK)
    curses.init_pair(2, curses.COLOR_WHITE,  curses.COLOR_BLACK)
    curses.init_pair(3, curses.COLOR_BLACK,  curses.COLOR_RED)
    curses.init_pair(4, curses.COLOR_BLACK,  curses.COLOR_WHITE)
    curses.init_pair(5, curses.COLOR_CYAN,   curses.COLOR_BLACK)
    curses.init_pair(6, curses.COLOR_YELLOW, curses.COLOR_BLACK)
    curses.init_pair(7, curses.COLOR_BLACK,  curses.COLOR_YELLOW)
    curses.curs_set(0)

    ACC  = curses.color_pair(1) | curses.A_BOLD
    NRM  = curses.color_pair(2)
    BHDR = curses.color_pair(3) | curses.A_BOLD
    BWHT = curses.color_pair(4) | curses.A_BOLD
    CYN  = curses.color_pair(5) | curses.A_BOLD
    YEL  = curses.color_pair(6) | curses.A_BOLD
    BYEL = curses.color_pair(7) | curses.A_BOLD
    DIM  = curses.color_pair(2) | curses.A_DIM

    display  = "0"
    expr     = ""
    memory   = 0
    history  = []
    sel_r, sel_c = 0, 0

    # Button grid: (label, value/action)
    BTNS = [
        [("MC","mc"),  ("MR","mr"),  ("M+","m+"),  ("M-","m-")],
        [("C","clear"),("±","neg"),  ("%","pct"),  ("÷","÷")  ],
        [("7","7"),    ("8","8"),    ("9","9"),    ("×","×")  ],
        [("4","4"),    ("5","5"),    ("6","6"),    ("−","−")  ],
        [("1","1"),    ("2","2"),    ("3","3"),    ("+","+")  ],
        [("0","0"),    (".","dot"),  ("√","sqrt"), ("=","=")  ],
    ]

    def calc_eval(ex):
        ex = ex.replace("×","*").replace("÷","/").replace("−","-")
        try:
            return str(eval(ex, {"__builtins__": {}, "sqrt": math.sqrt,
                                  "pi": math.pi, "e": math.e}))
        except:
            return "Error"

    while True:
        h, w = stdscr.getmaxyx()
        stdscr.erase()

        # Center the calculator
        calc_w = 34
        calc_h = 22
        ox = max(0, (w - calc_w) // 2)
        oy = max(0, (h - calc_h) // 2)

        # Border
        for y in range(calc_h):
            try:
                stdscr.addstr(oy+y, ox, "│" + " "*(calc_w-2) + "│", DIM)
            except: pass
        try:
            stdscr.addstr(oy,          ox, "╔" + "═"*(calc_w-2) + "╗", ACC)
            stdscr.addstr(oy+calc_h-1, ox, "╚" + "═"*(calc_w-2) + "╝", ACC)
        except: pass

        # Title
        title = "  🔢 DRACON CALC  "
        try: stdscr.addstr(oy, ox+1, title.center(calc_w-2, "═"), ACC)
        except: pass

        # Expression bar
        expr_disp = (expr[-calc_w+6:] if len(expr) > calc_w-6 else expr) or " "
        try:
            stdscr.addstr(oy+1, ox+2, f"{'':>{calc_w-4}}", DIM)
            stdscr.addstr(oy+1, ox+2, f"{expr_disp:>{calc_w-4}}", DIM)
        except: pass

        # Display
        disp_val = display[-14:] if len(display) > 14 else display
        try:
            stdscr.addstr(oy+2, ox+1, " "*(calc_w-2), NRM)
            stdscr.addstr(oy+2, ox+2, f"{disp_val:>{calc_w-4}}", YEL | curses.A_BOLD)
        except: pass

        try: stdscr.addstr(oy+3, ox+1, "─"*(calc_w-2), DIM)
        except: pass

        # Memory indicator
        if memory != 0:
            try: stdscr.addstr(oy+1, ox+2, f"M={memory}", CYN)
            except: pass

        # Buttons
        for r, row in enumerate(BTNS):
            for c, (label, val) in enumerate(row):
                bx = ox + 2 + c * 8
                by = oy + 4 + r * 3

                is_sel = (r == sel_r and c == sel_c)

                # Color by button type
                if val in ("=",):
                    attr = BHDR
                elif val in ("+", "−", "×", "÷"):
                    attr = ACC
                elif val in ("clear", "neg", "pct"):
                    attr = CYN
                elif val in ("mc","mr","m+","m-"):
                    attr = DIM
                else:
                    attr = NRM

                if is_sel:
                    attr = BYEL

                try:
                    btn = f"[ {label:^4} ]"
                    stdscr.addstr(by, bx, btn, attr)
                except: pass

        # History (last 3)
        try:
            stdscr.addstr(oy+3, ox + calc_w + 2, "History:", DIM)
            for i, h_item in enumerate(history[-3:]):
                stdscr.addstr(oy+4+i, ox+calc_w+2, h_item[:20], DIM)
        except: pass

        # Footer
        try:
            stdscr.addstr(oy+calc_h-2, ox+1,
                " Arrows:Move  Enter:Press  Q:Quit ", DIM)
        except: pass

        stdscr.refresh()

        key = stdscr.getch()

        if key in (ord('q'), ord('Q'), 27):
            break
        elif key == curses.KEY_UP:
            sel_r = max(0, sel_r - 1)
        elif key == curses.KEY_DOWN:
            sel_r = min(len(BTNS)-1, sel_r + 1)
        elif key == curses.KEY_LEFT:
            sel_c = max(0, sel_c - 1)
        elif key == curses.KEY_RIGHT:
            sel_c = min(3, sel_c + 1)
        elif key in (curses.KEY_ENTER, 10, 13):
            _, val = BTNS[sel_r][sel_c]
            # Handle button press
            if val.isdigit() or val == "dot":
                ch = "." if val == "dot" else val
                if display == "0" and ch != ".":
                    display = ch
                else:
                    display += ch
                expr += ch
            elif val in ("+", "−", "×", "÷"):
                expr += val
                display = "0"
            elif val == "=":
                result = calc_eval(expr + display)
                history.append(f"{expr}{display}={result}")
                display = result
                expr = ""
            elif val == "clear":
                display = "0"
                expr = ""
            elif val == "neg":
                try:
                    display = str(-float(display))
                    if display.endswith(".0"):
                        display = display[:-2]
                except: pass
            elif val == "pct":
                try:
                    display = str(float(display) / 100)
                except: pass
            elif val == "sqrt":
                try:
                    result = str(math.sqrt(float(display)))
                    if result.endswith(".0"):
                        result = result[:-2]
                    history.append(f"√{display}={result}")
                    display = result
                    expr = ""
                except: pass
            elif val == "mc":
                memory = 0
            elif val == "mr":
                display = str(memory)
            elif val == "m+":
                try: memory += float(display)
                except: pass
            elif val == "m-":
                try: memory -= float(display)
                except: pass
        # Number keys
        elif ord('0') <= key <= ord('9'):
            ch = chr(key)
            if display == "0":
                display = ch
            else:
                display += ch
            expr += ch
        elif key == ord('.'):
            if '.' not in display:
                display += '.'
                expr += '.'
        elif key in (ord('c'), ord('C')):
            display = "0"; expr = ""
        elif key == ord('\n') or key == ord('='):
            result = calc_eval(expr + display)
            history.append(f"{expr}{display}={result}")
            display = result; expr = ""
        elif key in (curses.KEY_BACKSPACE, 127):
            if len(display) > 1:
                display = display[:-1]
                if expr: expr = expr[:-1]
            else:
                display = "0"

def main():
    try:
        curses.wrapper(draw_calc)
    except KeyboardInterrupt:
        pass

if __name__ == "__main__":
    main()
