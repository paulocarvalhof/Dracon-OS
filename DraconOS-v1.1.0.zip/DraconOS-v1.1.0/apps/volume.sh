#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
#   Dracon OS v1.1.0 — Volume Control
#   apps/volume.sh
# ============================================================

R='\033[0;31m'; G='\033[0;32m'; C='\033[0;36m'
Y='\033[1;33m'; W='\033[1;37m'; DIM='\033[2m'; NC='\033[0m'

get_volume() {
  if command -v termux-volume &>/dev/null; then
    termux-volume 2>/dev/null | python3 -c "
import json,sys
try:
    data=json.load(sys.stdin)
    for d in data:
        if d.get('stream')=='music':
            print(d.get('volume',0))
            break
except: print(0)
"
  else
    echo "0"
  fi
}

set_volume() {
  local vol="$1"
  if command -v termux-volume &>/dev/null; then
    termux-volume music "$vol" 2>/dev/null
    echo -e "  ${G}✓ Volume set to ${vol}%${NC}"
  else
    echo -e "  ${Y}⚠ termux-api not installed${NC}"
    echo -e "  ${DIM}Install with: pkg install termux-api${NC}"
  fi
}

show_tui() {
  python3 << 'PYEOF'
import curses, subprocess, time

def get_vol():
    try:
        result = subprocess.run(["termux-volume"], capture_output=True, text=True, timeout=3)
        import json
        data = json.loads(result.stdout)
        for d in data:
            if d.get("stream") == "music":
                return d.get("volume", 0), d.get("maxVolume", 15)
    except:
        pass
    return 0, 15

def set_vol(vol):
    try:
        subprocess.run(["termux-volume", "music", str(vol)],
                       capture_output=True, timeout=3)
    except:
        pass

def draw(stdscr):
    curses.start_color()
    curses.init_pair(1, curses.COLOR_RED,    curses.COLOR_BLACK)
    curses.init_pair(2, curses.COLOR_WHITE,  curses.COLOR_BLACK)
    curses.init_pair(3, curses.COLOR_BLACK,  curses.COLOR_RED)
    curses.init_pair(4, curses.COLOR_CYAN,   curses.COLOR_BLACK)
    curses.init_pair(5, curses.COLOR_GREEN,  curses.COLOR_BLACK)
    curses.curs_set(0)

    ACC = curses.color_pair(1) | curses.A_BOLD
    NRM = curses.color_pair(2)
    HDR = curses.color_pair(3) | curses.A_BOLD
    CYN = curses.color_pair(4)
    GRN = curses.color_pair(5)
    DIM = curses.color_pair(2) | curses.A_DIM

    vol, max_vol = get_vol()

    while True:
        h, w = stdscr.getmaxyx()
        stdscr.erase()

        bw = 40
        bh = 14
        ox = (w - bw) // 2
        oy = (h - bh) // 2

        # Border
        try:
            stdscr.addstr(oy,     ox, "╔" + "═"*(bw-2) + "╗", ACC)
            stdscr.addstr(oy+bh-1,ox, "╚" + "═"*(bw-2) + "╝", ACC)
            for y in range(1, bh-1):
                stdscr.addstr(oy+y, ox, "║" + " "*(bw-2) + "║", DIM)
        except: pass

        # Title
        try: stdscr.addstr(oy, ox+1, "  🔊 DRACON VOLUME  ".center(bw-2,"═"), ACC)
        except: pass

        # Volume display
        pct = int(vol / max(max_vol, 1) * 100)
        bar_w = bw - 10
        filled = int(pct / 100 * bar_w)
        bar = "█" * filled + "░" * (bar_w - filled)

        try:
            stdscr.addstr(oy+3, ox+4, f"Volume: {pct:3d}%", NRM)
            col = ACC if pct > 80 else (CYN if pct > 40 else GRN)
            stdscr.addstr(oy+5, ox+3, f"[{bar}]", col)
        except: pass

        # Emoji indicator
        icon = "🔇" if pct == 0 else ("🔈" if pct < 33 else ("🔉" if pct < 66 else "🔊"))
        try: stdscr.addstr(oy+7, ox + bw//2 - 1, icon, NRM)
        except: pass

        # Controls
        try:
            stdscr.addstr(oy+9,  ox+6, "← →  Adjust volume", DIM)
            stdscr.addstr(oy+10, ox+6, "M    Mute / Unmute", DIM)
            stdscr.addstr(oy+11, ox+6, "Q    Close", DIM)
        except: pass

        stdscr.refresh()

        key = stdscr.getch()
        if key in (ord('q'), ord('Q'), 27):
            break
        elif key == curses.KEY_RIGHT:
            vol = min(max_vol, vol + 1)
            set_vol(vol)
        elif key == curses.KEY_LEFT:
            vol = max(0, vol - 1)
            set_vol(vol)
        elif key in (ord('m'), ord('M')):
            if vol > 0:
                vol = 0
            else:
                vol = max_vol // 2
            set_vol(vol)

try:
    curses.wrapper(draw)
except KeyboardInterrupt:
    pass
PYEOF
}

case "${1:-tui}" in
  get)    get_volume ;;
  set)    set_volume "${2:-50}" ;;
  up)     set_volume "$(( $(get_volume) + 10 ))" ;;
  down)   set_volume "$(( $(get_volume) - 10 ))" ;;
  mute)   set_volume "0" ;;
  tui|*)  show_tui ;;
esac
