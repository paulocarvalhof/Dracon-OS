#!/usr/bin/env python3
# ============================================================
#   Dracon OS v1.1.0 — Notification System
#   apps/notif/notif.py
# ============================================================

import sys, os, time, json, threading, subprocess

NOTIF_QUEUE = os.path.expanduser("~/.dracon/cache/notifications.json")
DISPLAY = os.environ.get("DISPLAY", ":1")

def ensure_queue():
    os.makedirs(os.path.dirname(NOTIF_QUEUE), exist_ok=True)
    if not os.path.exists(NOTIF_QUEUE):
        json.dump([], open(NOTIF_QUEUE, "w"))

def load_queue():
    try:
        return json.load(open(NOTIF_QUEUE))
    except:
        return []

def save_queue(q):
    json.dump(q, open(NOTIF_QUEUE, "w"), indent=2)

def show_xnotif(title, message, timeout=4, ntype="info"):
    """Show notification via xterm popup (works in VNC)."""
    icons = {"info": "ℹ", "success": "✓", "warning": "⚠", "error": "✗"}
    icon = icons.get(ntype, "ℹ")
    colors = {"info": "#58a6ff", "success": "#3fb950", "warning": "#d29922", "error": "#f84c4c"}
    color = colors.get(ntype, "#58a6ff")

    script = f"""
import time
try:
    import tkinter as tk
    root = tk.Tk()
    root.overrideredirect(True)
    root.attributes('-topmost', True)
    sw = root.winfo_screenwidth()
    root.geometry(f'320x80+{'{'}sw-335{'}'}+10')
    root.configure(bg='#161b22')

    frame = tk.Frame(root, bg='{color}', width=4)
    frame.pack(side='left', fill='y')

    content = tk.Frame(root, bg='#161b22', padx=10)
    content.pack(fill='both', expand=True)

    tk.Label(content, text='{icon} {title}', fg='{color}', bg='#161b22',
             font=('DejaVu Sans Bold', 11)).pack(anchor='w', pady=(8,2))
    tk.Label(content, text='{message}', fg='#8b949e', bg='#161b22',
             font=('DejaVu Sans', 9), wraplength=260).pack(anchor='w')

    root.after({timeout*1000}, root.destroy)
    root.mainloop()
except Exception as e:
    pass
"""
    try:
        env = os.environ.copy()
        env["DISPLAY"] = DISPLAY
        subprocess.Popen(
            ["python3", "-c", script],
            env=env,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
    except:
        # Fallback: terminal notification
        print(f"\033[0;36m[{ntype.upper()}]\033[0m {title}: {message}")


def send(title, message, ntype="info", timeout=4):
    """Send a notification."""
    ensure_queue()
    q = load_queue()
    entry = {
        "id": int(time.time() * 1000),
        "title": title,
        "message": message,
        "type": ntype,
        "time": time.strftime("%H:%M"),
        "read": False
    }
    q.append(entry)
    if len(q) > 50:
        q = q[-50:]
    save_queue(q)
    show_xnotif(title, message, timeout, ntype)


def list_notifs():
    """List all notifications."""
    ensure_queue()
    q = load_queue()
    if not q:
        print("  No notifications.")
        return
    print(f"\n  {'Time':<8} {'Type':<10} {'Title':<25} Message")
    print("  " + "─"*70)
    for n in q[-20:]:
        icon = {"info":"ℹ","success":"✓","warning":"⚠","error":"✗"}.get(n["type"],"·")
        unread = "●" if not n.get("read") else " "
        print(f"  {n['time']:<8} {icon} {n['type']:<8} {n['title']:<25} {n['message']}")
    print()


def clear_notifs():
    ensure_queue()
    save_queue([])
    print("  Notifications cleared.")


def daemon_loop():
    """Background daemon that shows system notifications."""
    ensure_queue()
    shown_ids = set()

    # Boot notification
    time.sleep(3)
    send("Dracon OS", "Welcome to Dracon OS v1.1.0! 🐉", "success", 5)

    while True:
        time.sleep(30)
        # System health check
        try:
            import psutil
            cpu = psutil.cpu_percent(interval=1)
            mem = psutil.virtual_memory().percent
            if cpu > 90:
                send("High CPU", f"CPU usage: {cpu:.0f}%", "warning")
            if mem > 90:
                send("High RAM", f"RAM usage: {mem:.0f}%", "warning")
        except:
            pass


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "help"

    if cmd == "send":
        title   = sys.argv[2] if len(sys.argv) > 2 else "Notification"
        message = sys.argv[3] if len(sys.argv) > 3 else ""
        ntype   = sys.argv[4] if len(sys.argv) > 4 else "info"
        send(title, message, ntype)

    elif cmd == "list":
        list_notifs()

    elif cmd == "clear":
        clear_notifs()

    elif cmd == "daemon":
        print("[notif] Notification daemon started")
        daemon_loop()

    else:
        print("Usage: notif.py <send|list|clear|daemon>")
        print("  send <title> <message> [info|success|warning|error]")
        print("  list                   — show all notifications")
        print("  clear                  — clear all notifications")
        print("  daemon                 — run background daemon")
