#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
#   Dracon OS v1.1.0 — Animated Boot Screen
#   core/bootscreen.sh
# ============================================================

R='\033[0;31m'; G='\033[0;32m'; C='\033[0;36m'
Y='\033[1;33m'; W='\033[1;37m'; DIM='\033[2m'
B='\033[0;34m'; M='\033[0;35m'; NC='\033[0m'
BOLD='\033[1m'; BLINK='\033[5m'

hide_cursor() { tput civis 2>/dev/null; }
show_cursor() { tput cnorm 2>/dev/null; }
clear_screen() { clear; }

trap show_cursor EXIT

# ─── Typing effect ──────────────────────────────────────────
type_text() {
  local text="$1"
  local color="${2:-$NC}"
  local delay="${3:-0.03}"
  echo -ne "$color"
  for ((i=0; i<${#text}; i++)); do
    echo -ne "${text:$i:1}"
    sleep "$delay"
  done
  echo -e "$NC"
}

# ─── Frame renderer ─────────────────────────────────────────
render_frame() {
  local frame="$1"
  clear
  case $frame in
    1)
      echo -e "\n\n\n\n\n\n"
      echo -e "                    ${R}·${NC}"
      ;;
    2)
      echo -e "\n\n\n\n\n"
      echo -e "                 ${R}· · ·${NC}"
      echo -e "                  ${R}· · ·${NC}"
      ;;
    3)
      echo -e "\n\n\n\n"
      echo -e "              ${R}· · · · · ·${NC}"
      echo -e "              ${R}· · · · · ·${NC}"
      echo -e "              ${R}· · · · · ·${NC}"
      ;;
    4)
      echo -e "\n\n\n"
      echo -e "   ${DIM}${W}██${NC}        ${R}· · · · · · · ·${NC}        ${DIM}${W}██${NC}"
      echo -e "   ${DIM}${W}██${NC}        ${R}· · · · · · · ·${NC}        ${DIM}${W}██${NC}"
      echo -e "   ${DIM}${W}██${NC}        ${R}· · · · · · · ·${NC}        ${DIM}${W}██${NC}"
      echo -e "   ${DIM}${W}██${NC}        ${R}· · · · · · · ·${NC}        ${DIM}${W}██${NC}"
      ;;
    5)
      echo -e "\n\n"
      echo -e "  ${R}██████╗ ██████╗  █████╗  ██████╗ ██████╗ ███╗   ██╗${NC}"
      echo -e "  ${DIM}${R}██╔══██╗██╔══██╗██╔══██╗██╔════╝██╔═══██╗████╗  ██║${NC}"
      echo -e "  ${R}██║  ██║██████╔╝███████║██║     ██║   ██║██╔██╗ ██║${NC}"
      echo -e "  ${DIM}${R}██║  ██║██╔══██╗██╔══██║██║     ██║   ██║██║╚██╗██║${NC}"
      echo -e "  ${R}██████╔╝██║  ██║██║  ██║╚██████╗╚██████╔╝██║ ╚████║${NC}"
      echo -e "  ${DIM}${R}╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝ ╚═════╝ ╚═╝  ╚═══╝${NC}"
      echo -e "\n              ${W}O  S${NC}   ${R}v1.1.0${NC}"
      ;;
    6)
      echo -e "\n\n"
      echo -e "  ${R}██████╗ ██████╗  █████╗  ██████╗ ██████╗ ███╗   ██╗${NC}"
      echo -e "  ${R}██╔══██╗██╔══██╗██╔══██╗██╔════╝██╔═══██╗████╗  ██║${NC}"
      echo -e "  ${R}██║  ██║██████╔╝███████║██║     ██║   ██║██╔██╗ ██║${NC}"
      echo -e "  ${R}██║  ██║██╔══██╗██╔══██║██║     ██║   ██║██║╚██╗██║${NC}"
      echo -e "  ${R}██████╔╝██║  ██║██║  ██║╚██████╗╚██████╔╝██║ ╚████║${NC}"
      echo -e "  ${R}╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝ ╚═════╝ ╚═╝  ╚═══╝${NC}"
      echo -e "\n              ${W}O  S${NC}   ${R}v1.1.0${NC}"
      echo -e "\n  ${DIM}Alpine-inspired Desktop OS for Termux + VNC${NC}"
      echo -e "  ${DIM}────────────────────────────────────────────${NC}"
      ;;
    7)
      echo -e "\n\n"
      echo -e "  ${R}██████╗ ██████╗  █████╗  ██████╗ ██████╗ ███╗   ██╗${NC}"
      echo -e "  ${R}██╔══██╗██╔══██╗██╔══██╗██╔════╝██╔═══██╗████╗  ██║${NC}"
      echo -e "  ${R}██║  ██║██████╔╝███████║██║     ██║   ██║██╔██╗ ██║${NC}"
      echo -e "  ${R}██║  ██║██╔══██╗██╔══██║██║     ██║   ██║██║╚██╗██║${NC}"
      echo -e "  ${R}██████╔╝██║  ██║██║  ██║╚██████╗╚██████╔╝██║ ╚████║${NC}"
      echo -e "  ${R}╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝ ╚═════╝ ╚═╝  ╚═══╝${NC}"
      echo -e "\n              ${W}O  S${NC}   ${R}v1.1.0${NC}"
      echo -e "\n  ${DIM}Alpine-inspired Desktop OS for Termux + VNC${NC}"
      echo -e "  ${DIM}────────────────────────────────────────────${NC}\n"

      # Boot log items
      BOOT_ITEMS=(
        "${G}[  OK  ]${NC} Started kernel subsystems"
        "${G}[  OK  ]${NC} Mounted virtual filesystems"
        "${G}[  OK  ]${NC} Loaded X11 display server"
        "${G}[  OK  ]${NC} Initialized VNC service"
        "${G}[  OK  ]${NC} Started Openbox window manager"
        "${G}[  OK  ]${NC} Applied ${R}Alpine${NC} theme"
        "${G}[  OK  ]${NC} Launched system services"
        "${Y}[ BOOT ]${NC} Starting ${W}Dracon OS${NC} desktop..."
      )
      for item in "${BOOT_ITEMS[@]}"; do
        echo -e "  $item"
        sleep 0.18
      done
      ;;
  esac
}

# ─── Progress bar ────────────────────────────────────────────
animated_progress() {
  local label="$1"
  local width=40
  echo ""
  for ((i=0; i<=width; i++)); do
    local pct=$((i * 100 / width))
    local bar=""
    for ((j=0; j<i; j++)); do bar+="█"; done
    for ((j=i; j<width; j++)); do bar+="░"; done
    echo -ne "  ${DIM}[${NC}${R}${bar}${NC}${DIM}]${NC} ${W}${pct}%${NC} ${DIM}${label}${NC}\r"
    sleep 0.04
  done
  echo -e "  ${DIM}[${NC}${G}$(printf '█%.0s' $(seq 1 $width))${NC}${DIM}]${NC} ${G}100%${NC} ${DIM}${label}${NC}"
}

# ─── Main boot animation ─────────────────────────────────────
main() {
  hide_cursor
  clear

  # Phase 1 — particle explosion
  for f in 1 2 3 4; do
    render_frame $f
    sleep 0.15
  done

  # Phase 2 — logo reveal
  render_frame 5
  sleep 0.4
  render_frame 6
  sleep 0.3
  render_frame 7

  # Phase 3 — progress bar
  animated_progress "Loading Dracon OS..."
  sleep 0.3

  echo ""
  echo -e "  ${G}✓${NC} ${W}Dracon OS v1.1.0 ready!${NC}"
  echo -e "  ${DIM}Starting desktop environment...${NC}"
  sleep 0.8

  show_cursor
}

main
