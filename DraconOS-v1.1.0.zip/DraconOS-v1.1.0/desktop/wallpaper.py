#!/usr/bin/env python3
# ============================================================
#   Dracon OS v1.1.0 — Wallpaper Generator (Enhanced)
#   desktop/wallpaper.py
# ============================================================

import sys, os, math, random

try:
    from PIL import Image, ImageDraw, ImageFont, ImageFilter
except ImportError:
    os.system("pip install pillow --quiet")
    from PIL import Image, ImageDraw, ImageFont, ImageFilter

THEMES = {
    "alpine": {
        "sky_top": (8, 10, 18), "sky_bot": (18, 22, 35),
        "mountain": (16, 22, 34), "mountain2": (22, 30, 46),
        "snow": (180, 195, 215), "moon": (248, 76, 76),
        "moon2": (255, 120, 120), "accent": (248, 76, 76),
        "text": (248, 76, 76), "grid": (255, 255, 255),
        "star_colors": [(255,255,255),(220,220,255),(255,220,220)],
        "aurora": False,
    },
    "dark": {
        "sky_top": (5, 5, 10), "sky_bot": (10, 10, 20),
        "mountain": (12, 12, 20), "mountain2": (18, 18, 30),
        "snow": (100, 100, 140), "moon": (80, 80, 200),
        "moon2": (120, 120, 255), "accent": (80, 80, 200),
        "text": (100, 100, 255), "grid": (100, 100, 200),
        "star_colors": [(255,255,255),(200,200,255)],
        "aurora": False,
    },
    "ocean": {
        "sky_top": (5, 20, 40), "sky_bot": (10, 40, 70),
        "mountain": (8, 35, 60), "mountain2": (12, 50, 80),
        "snow": (150, 220, 255), "moon": (0, 180, 255),
        "moon2": (80, 210, 255), "accent": (0, 180, 255),
        "text": (0, 200, 255), "grid": (0, 150, 200),
        "star_colors": [(255,255,255),(180,240,255)],
        "aurora": True,
    },
    "forest": {
        "sky_top": (5, 15, 10), "sky_bot": (10, 30, 20),
        "mountain": (10, 40, 20), "mountain2": (15, 55, 30),
        "snow": (180, 255, 180), "moon": (80, 200, 80),
        "moon2": (120, 240, 120), "accent": (80, 200, 80),
        "text": (80, 220, 80), "grid": (60, 160, 60),
        "star_colors": [(255,255,255),(200,255,200)],
        "aurora": True,
    },
}

def lerp_color(c1, c2, t):
    return tuple(int(c1[i] + (c2[i] - c1[i]) * t) for i in range(3))

def generate_wallpaper(output_path, width=1280, height=720, theme_name="alpine"):
    T = THEMES.get(theme_name, THEMES["alpine"])
    random.seed(42)

    img = Image.new("RGBA", (width, height), (0, 0, 0, 255))
    draw = ImageDraw.Draw(img)

    # ── Sky gradient ──
    for y in range(height):
        t = y / height
        col = lerp_color(T["sky_top"], T["sky_bot"], t)
        draw.line([(0, y), (width, y)], fill=col + (255,))

    # ── Stars ──
    for _ in range(350):
        sx = random.randint(0, width)
        sy = random.randint(0, int(height * 0.65))
        b = random.randint(60, 220)
        sc = random.choice(T["star_colors"])
        bc = tuple(int(c * b / 220) for c in sc)
        size = random.choice([1, 1, 1, 1, 2, 2, 3])
        twinkle = random.random()
        if twinkle > 0.97 and size >= 2:
            # Draw cross/sparkle for bright stars
            draw.ellipse([sx-size, sy-size, sx+size, sy+size], fill=bc+(200,))
            draw.line([(sx-size*3, sy), (sx+size*3, sy)], fill=bc+(80,), width=1)
            draw.line([(sx, sy-size*3), (sx, sy+size*3)], fill=bc+(80,), width=1)
        else:
            draw.ellipse([sx, sy, sx+size, sy+size], fill=bc+(180,))

    # ── Aurora (for ocean/forest themes) ──
    if T["aurora"]:
        aurora = Image.new("RGBA", (width, height), (0,0,0,0))
        adraw = ImageDraw.Draw(aurora)
        ac = T["moon"]
        for i in range(8):
            ax = random.randint(0, width)
            ay = random.randint(int(height*0.05), int(height*0.3))
            aw = random.randint(200, 500)
            ah = random.randint(40, 100)
            alpha = random.randint(15, 40)
            adraw.ellipse([ax-aw, ay-ah, ax+aw, ay+ah], fill=ac+(alpha,))
        aurora_blur = aurora.filter(ImageFilter.GaussianBlur(radius=30))
        img = Image.alpha_composite(img, aurora_blur)
        draw = ImageDraw.Draw(img)

    # ── Moon glow ──
    cx, cy = int(width * 0.75), int(height * 0.22)
    glow = Image.new("RGBA", (width, height), (0,0,0,0))
    gdraw = ImageDraw.Draw(glow)
    for r in range(160, 0, -1):
        alpha = int(2.5 * (1 - r/160))
        gdraw.ellipse([cx-r, cy-r, cx+r, cy+r], fill=T["moon"]+(alpha,))
    glow_blur = glow.filter(ImageFilter.GaussianBlur(radius=20))
    img = Image.alpha_composite(img, glow_blur)
    draw = ImageDraw.Draw(img)

    # Moon body
    draw.ellipse([cx-32, cy-32, cx+32, cy+32], fill=T["moon"]+(255,))
    draw.ellipse([cx-22, cy-22, cx+22, cy+22], fill=T["moon2"]+(255,))
    # Moon shine
    draw.ellipse([cx-10, cy-16, cx+2, cy-6], fill=(255,255,255,60))

    # ── Back mountains (distant, lighter) ──
    back_peaks = [
        (0, height), (int(width*0.08), int(height*0.72)),
        (int(width*0.16), int(height*0.80)),
        (int(width*0.25), int(height*0.62)),
        (int(width*0.33), int(height*0.74)),
        (int(width*0.42), int(height*0.58)),
        (int(width*0.50), int(height*0.68)),
        (int(width*0.58), int(height*0.55)),
        (int(width*0.66), int(height*0.65)),
        (int(width*0.74), int(height*0.60)),
        (int(width*0.82), int(height*0.70)),
        (int(width*0.90), int(height*0.63)),
        (int(width*0.96), int(height*0.72)),
        (width, int(height*0.68)), (width, height),
    ]
    draw.polygon(back_peaks, fill=T["mountain2"]+(200,))

    # ── Front mountains (main) ──
    front_peaks = [
        (0, height),
        (int(width*0.04), int(height*0.80)),
        (int(width*0.12), int(height*0.86)),
        (int(width*0.20), int(height*0.60)),
        (int(width*0.27), int(height*0.72)),
        (int(width*0.34), int(height*0.52)),
        (int(width*0.41), int(height*0.67)),
        (int(width*0.49), int(height*0.44)),
        (int(width*0.57), int(height*0.62)),
        (int(width*0.64), int(height*0.50)),
        (int(width*0.71), int(height*0.70)),
        (int(width*0.79), int(height*0.57)),
        (int(width*0.86), int(height*0.74)),
        (int(width*0.93), int(height*0.67)),
        (width, int(height*0.80)),
        (width, height),
    ]
    draw.polygon(front_peaks, fill=T["mountain"]+(255,))

    # ── Snow caps ──
    snow_peaks = [
        [(int(width*0.18), int(height*0.64)), (int(width*0.20), int(height*0.60)),
         (int(width*0.22), int(height*0.64))],
        [(int(width*0.32), int(height*0.56)), (int(width*0.34), int(height*0.52)),
         (int(width*0.36), int(height*0.56))],
        [(int(width*0.46), int(height*0.48)), (int(width*0.49), int(height*0.44)),
         (int(width*0.52), int(height*0.48))],
        [(int(width*0.62), int(height*0.54)), (int(width*0.64), int(height*0.50)),
         (int(width*0.66), int(height*0.54))],
        [(int(width*0.77), int(height*0.61)), (int(width*0.79), int(height*0.57)),
         (int(width*0.81), int(height*0.61))],
    ]
    snow_c = T["snow"]
    for snow in snow_peaks:
        draw.polygon(snow, fill=snow_c+(220,))
        # Snow glow
        sg = Image.new("RGBA", (width, height), (0,0,0,0))
        ImageDraw.Draw(sg).polygon(snow, fill=snow_c+(40,))
        sg_blur = sg.filter(ImageFilter.GaussianBlur(radius=4))
        img = Image.alpha_composite(img, sg_blur)
        draw = ImageDraw.Draw(img)

    # ── Grid overlay (subtle) ──
    grid = Image.new("RGBA", (width, height), (0,0,0,0))
    gdraw = ImageDraw.Draw(grid)
    gc = T["grid"]
    for x in range(0, width, 80):
        gdraw.line([(x, 0), (x, height)], fill=gc+(6,), width=1)
    for y in range(0, height, 80):
        gdraw.line([(0, y), (width, y)], fill=gc+(6,), width=1)
    img = Image.alpha_composite(img, grid)
    draw = ImageDraw.Draw(img)

    # ── Bottom accent line ──
    draw.rectangle([(0, height-3), (width, height)], fill=T["accent"]+(255,))

    # ── Logo text ──
    try:
        font_logo = ImageFont.truetype(
            "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 52)
        font_sub  = ImageFont.truetype(
            "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 14)
        font_ver  = ImageFont.truetype(
            "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 14)
    except:
        font_logo = font_sub = font_ver = ImageFont.load_default()

    # Logo glow
    logo_text = "DRACON OS"
    bbox = draw.textbbox((0,0), logo_text, font=font_logo)
    tw = bbox[2]-bbox[0]
    tx = (width - tw) // 2
    ty = int(height * 0.10)

    glow_l = Image.new("RGBA", (width, height), (0,0,0,0))
    gdraw_l = ImageDraw.Draw(glow_l)
    tc = T["text"]
    for offset in range(8, 0, -1):
        alpha = int(15 * (1 - offset/8))
        gdraw_l.text((tx+offset, ty+offset), logo_text, fill=tc+(alpha,), font=font_logo)
        gdraw_l.text((tx-offset, ty-offset), logo_text, fill=tc+(alpha,), font=font_logo)
    glow_l_blur = glow_l.filter(ImageFilter.GaussianBlur(radius=6))
    img = Image.alpha_composite(img, glow_l_blur)
    draw = ImageDraw.Draw(img)

    draw.text((tx+2, ty+2), logo_text, fill=(0,0,0,100), font=font_logo)
    draw.text((tx, ty), logo_text, fill=tc+(255,), font=font_logo)

    # Subtitle
    sub_text = "Alpine-inspired Desktop OS  •  Termux + VNC"
    sbbox = draw.textbbox((0,0), sub_text, font=font_sub)
    sw = sbbox[2]-sbbox[0]
    draw.text(((width-sw)//2, ty+62), sub_text, fill=(100,110,130,200), font=font_sub)

    # Version badge
    ver_text = f"v1.1.0"
    vbbox = draw.textbbox((0,0), ver_text, font=font_ver)
    vw = vbbox[2]-vbbox[0]
    vx = (width - vw) // 2
    vy = ty + 82
    draw.rounded_rectangle([vx-10, vy-4, vx+vw+10, vy+20], radius=8,
                            fill=tc+(40,), outline=tc+(120,), width=1)
    draw.text((vx, vy), ver_text, fill=tc+(220,), font=font_ver)

    # Save
    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    img.convert("RGB").save(output_path, "PNG")
    print(f"[wallpaper] Generated ({theme_name}): {output_path}")


if __name__ == "__main__":
    output = sys.argv[1] if len(sys.argv) > 1 else \
        os.path.expanduser("~/.dracon/themes/alpine/wallpaper.png")
    theme  = sys.argv[2] if len(sys.argv) > 2 else "alpine"
    generate_wallpaper(output, theme_name=theme)
