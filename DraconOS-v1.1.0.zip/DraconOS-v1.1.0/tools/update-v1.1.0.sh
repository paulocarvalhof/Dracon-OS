#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
#   Dracon OS — Update to v1.1.0
#   tools/update-v1.1.0.sh
# ============================================================

DRACON_HOME="$HOME/.dracon"
R='\033[0;31m'; G='\033[0;32m'; C='\033[0;36m'
Y='\033[1;33m'; W='\033[1;37m'; DIM='\033[2m'; NC='\033[0m'

clear
echo -e "${R}"
echo '  ██████╗ ██████╗  █████╗  ██████╗ ██████╗ ███╗   ██╗'
echo '  ██╔══██╗██╔══██╗██╔══██╗██╔════╝██╔═══██╗████╗  ██║'
echo '  ██║  ██║██████╔╝███████║██║     ██║   ██║██╔██╗ ██║'
echo '  ██║  ██║██╔══██╗██╔══██║██║     ██║   ██║██║╚██╗██║'
echo '  ██████╔╝██║  ██║██║  ██║╚██████╗╚██████╔╝██║ ╚████║'
echo '  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝ ╚═════╝ ╚═╝  ╚═══╝'
echo -e "${W}                  Updater → ${R}v1.1.0${NC}\n"

SRC="$(cd "$(dirname "$0")/.." && pwd)"

log_ok()   { echo -e "  ${G}[ OK ]${NC} $1"; }
log_info() { echo -e "  ${C}[INFO]${NC} $1"; }
log_step() { echo -e "\n  ${W}══ $1 ══${NC}"; }

log_step "Backing up current version"
cp -r "$DRACON_HOME" "$DRACON_HOME.bak.$(date +%Y%m%d)" 2>/dev/null
log_ok "Backup created"

log_step "Installing new files"

# Core
cp "$SRC/core/bootscreen.sh" "$DRACON_HOME/bin/" 2>/dev/null
log_ok "Animated boot screen"

# Desktop
cp "$SRC/desktop/wallpaper.py" "$DRACON_HOME/bin/" 2>/dev/null
log_ok "Enhanced wallpaper generator (4 themes)"

# Apps
mkdir -p "$DRACON_HOME/apps/store" "$DRACON_HOME/apps/settings" \
         "$DRACON_HOME/apps/calculator" "$DRACON_HOME/apps/editor" \
         "$DRACON_HOME/apps/notif"

cp "$SRC/apps/store/store.py"           "$DRACON_HOME/apps/store/"
cp "$SRC/apps/settings/settings.py"     "$DRACON_HOME/apps/settings/"
cp "$SRC/apps/calculator/calc.py"       "$DRACON_HOME/apps/calculator/"
cp "$SRC/apps/editor/editor.py"         "$DRACON_HOME/apps/editor/"
cp "$SRC/apps/notif/notif.py"           "$DRACON_HOME/apps/notif/"
cp "$SRC/apps/volume.sh"                "$DRACON_HOME/bin/"
log_ok "Dracon Store"
log_ok "Settings app"
log_ok "Calculator"
log_ok "Text editor (DraconEdit)"
log_ok "Notification system"
log_ok "Volume control"

# Register new commands
ln -sf "$DRACON_HOME/apps/store/store.py"         "$PREFIX/bin/dracon-store"   2>/dev/null
ln -sf "$DRACON_HOME/apps/settings/settings.py"   "$PREFIX/bin/dracon-settings"2>/dev/null
ln -sf "$DRACON_HOME/apps/calculator/calc.py"     "$PREFIX/bin/dracon-calc"    2>/dev/null
ln -sf "$DRACON_HOME/apps/editor/editor.py"       "$PREFIX/bin/dracon-edit"    2>/dev/null
ln -sf "$DRACON_HOME/apps/notif/notif.py"         "$PREFIX/bin/dracon-notif"   2>/dev/null
ln -sf "$DRACON_HOME/bin/volume.sh"               "$PREFIX/bin/dracon-volume"  2>/dev/null
chmod +x "$PREFIX/bin/dracon-"* 2>/dev/null

log_step "Installing new themes"
for theme in alpine dark ocean forest; do
  mkdir -p "$DRACON_HOME/themes/$theme"
done
cp -r "$SRC/themes/"* "$DRACON_HOME/themes/" 2>/dev/null
log_ok "Themes: alpine, dark, ocean, forest"

log_step "Generating wallpapers"
for theme in alpine dark ocean forest; do
  python3 "$DRACON_HOME/bin/wallpaper.py" \
    "$DRACON_HOME/themes/$theme/wallpaper.png" "$theme" 2>/dev/null &
  log_ok "Generating $theme wallpaper..."
done
wait
log_ok "All wallpapers generated"

log_step "Updating desktop menu"

cat > "$HOME/.config/openbox/menu.xml" << 'MENU'
<?xml version="1.0" encoding="UTF-8"?>
<openbox_menu>
  <menu id="root-menu" label="Dracon OS">

    <item label="🖥️  Terminal">
      <action name="Execute"><command>xterm -bg "#0d1117" -fg "#c9d1d9" -fa "Monospace" -fs 11</command></action>
    </item>

    <item label="📁 File Manager">
      <action name="Execute"><command>xterm -e mc</command></action>
    </item>

    <separator label="── Applications ──"/>

    <item label="🛍️  Dracon Store">
      <action name="Execute"><command>xterm -title "Dracon Store" -bg "#0d1117" -fg "#c9d1d9" -e python3 ~/.dracon/apps/store/store.py</command></action>
    </item>

    <item label="📊 System Monitor">
      <action name="Execute"><command>xterm -title "Monitor" -bg "#0d1117" -fg "#c9d1d9" -e python3 ~/.dracon/bin/monitor.py</command></action>
    </item>

    <item label="🔢 Calculator">
      <action name="Execute"><command>xterm -title "Calculator" -bg "#0d1117" -fg "#c9d1d9" -e python3 ~/.dracon/apps/calculator/calc.py</command></action>
    </item>

    <item label="✏️  Text Editor">
      <action name="Execute"><command>xterm -title "DraconEdit" -bg "#0d1117" -fg "#c9d1d9" -e python3 ~/.dracon/apps/editor/editor.py</command></action>
    </item>

    <separator label="── Settings ──"/>

    <item label="⚙️  Settings">
      <action name="Execute"><command>xterm -title "Settings" -bg "#0d1117" -fg "#c9d1d9" -e python3 ~/.dracon/apps/settings/settings.py</command></action>
    </item>

    <item label="🔊 Volume">
      <action name="Execute"><command>xterm -title "Volume" -bg "#0d1117" -fg "#c9d1d9" -e bash ~/.dracon/bin/volume.sh</command></action>
    </item>

    <item label="🔔 Notifications">
      <action name="Execute"><command>xterm -title "Notifications" -bg "#0d1117" -fg "#c9d1d9" -e python3 ~/.dracon/apps/notif/notif.py list</command></action>
    </item>

    <separator/>

    <item label="🔄 Restart Desktop">
      <action name="Execute"><command>bash ~/.dracon/bin/desktop.sh</command></action>
    </item>

    <item label="⏹️  Stop Dracon OS">
      <action name="Execute"><command>dracon stop</command></action>
    </item>

  </menu>
</openbox_menu>
MENU
log_ok "Desktop menu updated with all new apps"

log_step "Updating version file"
echo "DRACON_VERSION=1.1.0" > "$DRACON_HOME/config/version"
log_ok "Version set to 1.1.0"

echo ""
echo -e "  ${G}╔══════════════════════════════════════════╗${NC}"
echo -e "  ${G}║${NC}   ${W}Dracon OS updated to v1.1.0!${NC}           ${G}║${NC}"
echo -e "  ${G}╠══════════════════════════════════════════╣${NC}"
echo -e "  ${G}║${NC}                                          ${G}║${NC}"
echo -e "  ${G}║${NC}  ${C}New commands:${NC}                          ${G}║${NC}"
echo -e "  ${G}║${NC}  ${R}dracon-store${NC}     → App Store            ${G}║${NC}"
echo -e "  ${G}║${NC}  ${R}dracon-settings${NC}  → Settings             ${G}║${NC}"
echo -e "  ${G}║${NC}  ${R}dracon-calc${NC}      → Calculator           ${G}║${NC}"
echo -e "  ${G}║${NC}  ${R}dracon-edit${NC}      → Text Editor          ${G}║${NC}"
echo -e "  ${G}║${NC}  ${R}dracon-notif${NC}     → Notifications        ${G}║${NC}"
echo -e "  ${G}║${NC}  ${R}dracon-volume${NC}    → Volume Control       ${G}║${NC}"
echo -e "  ${G}║${NC}                                          ${G}║${NC}"
echo -e "  ${G}║${NC}  ${Y}Restart to apply:${NC}  dracon restart       ${G}║${NC}"
echo -e "  ${G}║${NC}                                          ${G}║${NC}"
echo -e "  ${G}╚══════════════════════════════════════════╝${NC}"
echo ""
